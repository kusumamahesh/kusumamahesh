package com.sec.AuthServerSecurity.config;
public interface Constants {

//	public String ROLE_ADMIN = "ADMIN"; //FHIR
//	public String ROLE_USER = "USER";

	
	public String BUSINESSPARTNER = "BUSINESSPARTNER";
	public String ROLE_ADMIN = "ADMIN";
	public String ROLE_USER = "USER";
	public String SUPERADMIN = "SUPERADMIN";
	public String GOODSRECEIPIENT = "GOODSRECEIPIENT";
//	public String GETDropDownData = "/SCMXPert/getDDData";
	
}