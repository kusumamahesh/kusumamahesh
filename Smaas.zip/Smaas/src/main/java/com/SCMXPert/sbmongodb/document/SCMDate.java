package com.SCMXPert.sbmongodb.document;

public class SCMDate {

	private String Date;
	private String TimeZone;
	
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getTimeZone() {
		return TimeZone;
	}
	public void setTimeZone(String timeZone) {
		TimeZone = timeZone;
	}
	
	
}
