//package com.SCMXPert.sbmongodb.repository.impl;
//
//import java.util.Comparator;
//
//
//import com.SCMXPert.sbmongodb.document.Devicedatatemp;
//
//public class CompartorSorting  {
//	public static Comparator<Devicedatatemp> StuNameComparator = new Comparator<Devicedatatemp>() {
//
//		public int compare(Devicedatatemp s1, Devicedatatemp s2) {
//		   String StudentName1 = s1.getUTC().toUpperCase();
//		   String StudentName2 = s2.getUTC().toUpperCase();
//
//		   //ascending order
//		   return StudentName1.compareTo(StudentName2);
//
//		   //descending order
//		   //return StudentName2.compareTo(StudentName1);
//	    }};
//}
