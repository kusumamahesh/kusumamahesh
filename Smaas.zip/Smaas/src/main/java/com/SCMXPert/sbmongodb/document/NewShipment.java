package com.SCMXPert.sbmongodb.document;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/*@Document(collection = "new_shipment")
public class NewShipment {

	@Id
	private ObjectId id;
	
	private String internal_shipment_id;
	private String customerName;
	private String partnerName;
	private String shipmentNumber;
	private List<References> typeOfReference;
	private String shipmentDescription;
	//private 
	
}
*/