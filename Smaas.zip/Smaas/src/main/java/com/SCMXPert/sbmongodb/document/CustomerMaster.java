package com.SCMXPert.sbmongodb.document;

public class CustomerMaster {

	//General Infromation
	private String CustomerId;
	
}
