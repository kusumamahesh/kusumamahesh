package com.SCMXPert.sbmongodb.document;

public class UnApprovedUsers {

	private String userEmail;

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserEmail() {
		return userEmail;
	}
}
