package com.SCMXPert.sbmongodb.document;

import javax.validation.constraints.Pattern;

public class UpdateEvent {
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String Shipment_Number;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String Partner;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String Event;
	private String DateandTime;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String EventId;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String EventType;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String PartnerFrom;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String EventReferenceNumber;
	private String TypeOfReference;
	private String Comments;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String EventStatus;
	private String Event_Exec_Date;
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String Evidence;
	public String getDevice_Id() {
		return Device_Id;
	}
	public void setDevice_Id(String device_Id) {
		Device_Id = device_Id;
	}
	@Pattern(message="Invalid Input", regexp = "|.[a-zA-Z0-9  _.,-]+")
	private String Device_Id;
	
	
	
	public String getEvent_Exec_Date() {
		return Event_Exec_Date;
	}
	public void setEvent_Exec_Date(String event_Exec_Date) {
		Event_Exec_Date = event_Exec_Date;
	}
	private String[] Evidencelist;
	public String getShipment_Number() {
		return Shipment_Number;
	}
	public void setShipment_Number(String shipment_Number) {
		Shipment_Number = shipment_Number;
	}
	public String getPartner() {
		return Partner;
	}
	public void setPartner(String partner) {
		Partner = partner;
	}
	public String getEvent() {
		return Event;
	}
	public void setEvent(String event) {
		Event = event;
	}
	public String getDateandTime() {
		return DateandTime;
	}
	public void setDateandTime(String dateandTime) {
		DateandTime = dateandTime;
	}
	public String getEventId() {
		return EventId;
	}
	public void setEventId(String eventId) {
		EventId = eventId;
	}
	public String getEventType() {
		return EventType;
	}
	public void setEventType(String eventType) {
		EventType = eventType;
	}
	public String getPartnerFrom() {
		return PartnerFrom;
	}
	public void setPartnerFrom(String partnerFrom) {
		PartnerFrom = partnerFrom;
	}
	public String getEventReferenceNumber() {
		return EventReferenceNumber;
	}
	public void setEventReferenceNumber(String eventReferenceNumber) {
		EventReferenceNumber = eventReferenceNumber;
	}
	public String getTypeOfReference() {
		return TypeOfReference;
	}
	public void setTypeOfReference(String typeOfReference) {
		TypeOfReference = typeOfReference;
	}
	public String getComments() {
		return Comments;
	}
	public void setComments(String comments) {
		Comments = comments;
	}
	public String getEventStatus() {
		return EventStatus;
	}
	public void setEventStatus(String eventStatus) {
		EventStatus = eventStatus;
	}
	public String[] getEvidencelist() {
		return Evidencelist;
	}
	public void setEvidencelist(String[] evidencelist) {
		Evidencelist = evidencelist;
	}
	public String getEvidence() {
		return Evidence;
	}
	public void setEvidence(String evidence) {
		Evidence = evidence;
	}
	
	
	
	
}
