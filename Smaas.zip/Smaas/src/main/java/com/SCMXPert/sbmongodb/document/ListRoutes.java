package com.SCMXPert.sbmongodb.document;

import java.util.List;

public class ListRoutes {

	private List<Route> routes;

	public void setRoutes(List<Route> routes) {
		this.routes = routes;
	}

	public List<Route> getRoutes() {
		return routes;
	}
}
