/*
 * package com.SCMXPert.sbmongodb.repository;
 * 
 * import java.util.Date;
 * 
 * public interface ShipmentsRepositoryCustom {
 * 
 * public String getMaxEmpId();
 * 
 * public long update(String BP_Type, String fullName, Date hireDate);
 * 
 * }
 */