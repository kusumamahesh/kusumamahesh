package com.SCMXPert.sbmongodb.document;

import java.util.List;

public class DeviceCreateTransferDropDown {

	private String InternalTransferId;
	private String Locations;
	
	public String getInternalTransferId() {
		return InternalTransferId;
	}
	public void setInternalTransferId(String internalTransferId) {
		InternalTransferId = internalTransferId;
	}
	public String getLocations() {
		return Locations;
	}
	public void setLocations(String string) {
		Locations = string;
	}
	
}
