package com.SCMXPert.sbmongodb.controller;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.DoubleSummaryStatistics;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import javax.validation.Valid;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.SCMXPert.sbmongodb.customImpl.CompleteEmailCalculations;
import com.SCMXPert.sbmongodb.customImpl.PDFGenerator;
import com.SCMXPert.sbmongodb.document.AddEvent;
import com.SCMXPert.sbmongodb.document.AlertMaster;
import com.SCMXPert.sbmongodb.document.AlertProfile;
import com.SCMXPert.sbmongodb.document.AllEvents;
import com.SCMXPert.sbmongodb.document.BPList;
import com.SCMXPert.sbmongodb.document.BusinessPartner;
import com.SCMXPert.sbmongodb.document.Calculations;
import com.SCMXPert.sbmongodb.document.CanCompleteShipmentDto;
import com.SCMXPert.sbmongodb.document.CompleteShipment;
import com.SCMXPert.sbmongodb.document.CompleteShipmentDto;
import com.SCMXPert.sbmongodb.document.CopyAddEvent;
import com.SCMXPert.sbmongodb.document.CreateNewShipmentDto;
import com.SCMXPert.sbmongodb.document.CreateShipment;
import com.SCMXPert.sbmongodb.document.CustomBP;
import com.SCMXPert.sbmongodb.document.Customer;
import com.SCMXPert.sbmongodb.document.DeviceDataStream;
import com.SCMXPert.sbmongodb.document.DeviceDataTempDto;
import com.SCMXPert.sbmongodb.document.Devicedatatemp;
import com.SCMXPert.sbmongodb.document.Devices;
import com.SCMXPert.sbmongodb.document.DropDownDto;
import com.SCMXPert.sbmongodb.document.DropDownShipmentDetails;
import com.SCMXPert.sbmongodb.document.ErrorExcel;
import com.SCMXPert.sbmongodb.document.EventId;
import com.SCMXPert.sbmongodb.document.Events;
import com.SCMXPert.sbmongodb.document.FiltersData;
import com.SCMXPert.sbmongodb.document.Goods;
import com.SCMXPert.sbmongodb.document.Response;
import com.SCMXPert.sbmongodb.document.Search;
import com.SCMXPert.sbmongodb.document.ShipmentDraftDto;
import com.SCMXPert.sbmongodb.document.ShipmentDraftPartialGet;
import com.SCMXPert.sbmongodb.document.ShipmentDrafts;
import com.SCMXPert.sbmongodb.document.ShipmentTransactionDeviceData;
import com.SCMXPert.sbmongodb.document.ShipmentTransactions;
import com.SCMXPert.sbmongodb.document.ShipmentWayinfo;
import com.SCMXPert.sbmongodb.document.Shipments;
import com.SCMXPert.sbmongodb.document.UpdateEvent;
import com.SCMXPert.sbmongodb.document.UpdateNewPlusEventDto;
import com.SCMXPert.sbmongodb.document.UpdateShipmentEvent;
import com.SCMXPert.sbmongodb.repository.AlertProfileRepository;
import com.SCMXPert.sbmongodb.repository.AlertRepository;
import com.SCMXPert.sbmongodb.repository.BusinessPartnerRepository;
import com.SCMXPert.sbmongodb.repository.CompleteShipmentRepo;
import com.SCMXPert.sbmongodb.repository.CopyAddEventRepo;
import com.SCMXPert.sbmongodb.repository.CustomerRepository;
import com.SCMXPert.sbmongodb.repository.DeviceDataStreamRepository;
import com.SCMXPert.sbmongodb.repository.DevicesRepository;
import com.SCMXPert.sbmongodb.repository.DropDownRepo;
import com.SCMXPert.sbmongodb.repository.DropDownShipmentDetailsRepo;
import com.SCMXPert.sbmongodb.repository.SaveDraftsRepo;
import com.SCMXPert.sbmongodb.repository.ShipmentDraftsRepo;
import com.SCMXPert.sbmongodb.repository.ShipmentSaveDraftRepo;
import com.SCMXPert.sbmongodb.repository.ShipmentTransactionsRepository;
import com.SCMXPert.sbmongodb.repository.ShipmentsRepository;
import com.SCMXPert.sbmongodb.repository.UpdateEventGetRepo;
import com.SCMXPert.sbmongodb.sequence.dao.EvenIdSequenceDao;
import com.itextpdf.text.DocumentException;
import com.mongodb.BasicDBObject;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvocationType;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.services.lambda.model.ServiceException;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;

@Controller
@RequestMapping("/SCMXPert")
@CrossOrigin(origins = { "https://www.smaas.live", "https://smaas.live", "http://172.17.211.224:3000",
		"http://127.0.0.1:8081","https://136.233.44.146:8081" })

public class ShipmentController {

	@Autowired
	private ShipmentsRepository shiprepo;

	@Autowired
	private CompleteShipmentRepo completeShipRepo;

	@Autowired
	private ShipmentTransactionsRepository shiptransrepo;

	@Autowired
	private CustomerRepository customerepo;

	@Autowired
	private DeviceDataStreamRepository devicedatarepo;

	@Autowired
	private DevicesRepository devicerepo;

	@Autowired
	private DropDownRepo dprepo;

	@Autowired
	private ShipmentDraftsRepo shipmentDraftsRepo;

	@Autowired
	private EvenIdSequenceDao evendiddao;

	@Autowired
	MongoOperations mongoOperation;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	private DropDownShipmentDetailsRepo ddrepo1;

	@Autowired
	private BusinessPartnerRepository bussinesRepo;

	@Autowired
	private ShipmentSaveDraftRepo savedraftRepo;

	@Autowired
	private SaveDraftsRepo saveShipDraftsRepo;

	@Autowired
	private UpdateEventGetRepo updateeventgetrepo;

	@Autowired
	private CopyAddEventRepo copyaddrepo;

	@Autowired
	private AlertProfileRepository alertprofilerepo;

	@Autowired
	private AlertRepository alertmasterrepo;

	@Autowired
	private MailSenderService mailsend;

	@Autowired
	private PDFGenerator genratePDF;
	@Autowired
	private CompleteEmailCalculations cec;

	private static final String HOSTING_SEQ_KEY = "hosting";

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//// The Below Rest End Points are The actual data Model for the Shipment

	public static <T> List<T> convertArrayTOList(T array[]) {
		List<T> list = new ArrayList<>();
		for (T t : array) {
			list.add(t);
		}
		return list;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/addUpdateNewEvent")
	public boolean addUpdateNewEvent(@Validated @RequestBody UpdateNewPlusEventDto dto) {

		boolean flag = false;
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String strDate = formatter.format(date);
		try {
			ShipmentTransactions shipmentTxns1 = new ShipmentTransactions();
			shipmentTxns1.setCustomer_Id(dto.getCustomerId());
			shipmentTxns1.setShipment_Id(dto.getShipment_Number());
			shipmentTxns1.setShipment_Num(dto.getShipment_Num());
			shipmentTxns1.setDevice_Id(dto.getDeviceId());
			shipmentTxns1.setMode_of_Transport(dto.getMode());
			shipmentTxns1.setPartner_From(dto.getParnterFrom());
			shipmentTxns1.setEvent_Id(dto.getEvent_Id());
			shipmentTxns1.setPartner_To(dto.getPartnerTo());
			shipmentTxns1.setEvent_Name(dto.getEventName());
			// dto.getDateAndTime()
			shipmentTxns1.setEvent_Exec_Date("");
			shipmentTxns1.setComments(dto.getComments());
			List<@Valid ShipmentTransactions> shpt = shiptransrepo.findByShipment_Id(dto.getShipment_Num());
			long seqid = 0;
			for (ShipmentTransactions shp : shpt) {
				seqid = shp.getEvent_SNo();
			}
			shipmentTxns1.setEvent_SNo(seqid + 1);
			shipmentTxns1.setEvent_Status("Queued");
			shipmentTxns1.setExpected_Date_At_BP(strDate);
			shipmentTxns1.setShip_Date_From_BP(strDate);
			shiptransrepo.insert(shipmentTxns1);
			flag = true;
			return flag;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return flag;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/addNewEvent")
	public boolean addEvent(@Validated @RequestBody  AddEvent event) {
		boolean flag = false;
		List<@Valid Events> eveList = new ArrayList<>();
		try {
			Events events = new Events();
			BusinessPartner partner = bussinesRepo.findByBP_Id(event.getBussines_Id());
			if (partner.getBP_Id().equals(event.getBussines_Id())) {
				eveList.addAll(partner.getEvents());
				for (Events ev : partner.getEvents()) {
					if (!ev.getEvent_Id().equals(event.getEvent_Id())
							&& !ev.getEvent_Status().equals(event.getEventStatus())) {
						events.setEvent_Id(event.getEvent_Id());
						events.setEvent_Status(event.getEventStatus());
					} else {
						System.out.println("Event alredy exists");
						flag = false;
						return flag;
					}
				}
				eveList.add(events);
			}
			Query query1 = new Query();
			query1.addCriteria(new Criteria().andOperator(Criteria.where("BP_Id").is(event.getBussines_Id())));
			Update update1 = new Update();
			update1.set("Events", eveList);
			mongoTemplate.updateMulti(query1, update1, "BusinessPartner");
			flag = true;
			return flag;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return flag;

	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/addCopyEvent")
	public boolean addCopyEvent(@Validated @RequestBody CopyAddEvent addeventdraft) {
		boolean flag = false;
		try {
			CopyAddEvent cae = copyaddrepo.findByEvent_Id(addeventdraft.getEvent_Id());
			if (cae.getEvent_Id().equals(addeventdraft.getEvent_Id())) {
				flag = false;
				return flag;
			}
		} catch (Exception e) {
		}
		copyaddrepo.insert(addeventdraft);
		flag = true;
		return flag;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getCopyEvent/{EventId}")
	public CopyAddEvent getCopyEvent(@PathVariable(value = "EventId") String EventId) {
		return copyaddrepo.findByEvent_Id(EventId);
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getDropdowndata/{Customer_Id}")
	public BusinessPartner DropDownBusinessPartner(@PathVariable(value = "Customer_Id") String Customer_Id) {
		return bussinesRepo.findByBP_Id(Customer_Id.trim());

	}

	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDDDataBP/{Customer_Id}") public DropDownBusinessPartner
	 * getDDDataBP(@PathVariable(value = "Customer_Id") String Customer_id) throws
	 * Exception {
	 * 
	 * 
	 * 
	 * List<CustomBP> listbp = new ArrayList<>(); BusinessPartner partner = null;
	 * CustomBP custBpp = null; DropDownShipmentDetails dp =
	 * ddrepo1.findByCustomer_id(Customer_id.trim()); String[] list3 =
	 * dp.getBusiness_Partner_Id(); List<String> list4 = convertArrayTOList(list3);
	 * System.out.println(list4); for (String ar : list4) { custBpp = new
	 * CustomBP(); partner = bussinesRepo.findByBP_id(ar.trim());
	 * System.out.println(partner.getBP_Id()); if (partner.getBP_Id().equals(ar) &&
	 * !listbp.contains(partner.getBP_Id())) { if
	 * (listbp.contains(partner.getBP_Id())) { break; } else {
	 * custBpp.setBP_Id(partner.getBP_Id());
	 * custBpp.setCompany_Name(partner.getCompany_Name());
	 * custBpp.setEvents(partner.getEvents()); listbp.add(custBpp); } } }
	 * System.out.println(listbp); dp.setBussinesPartnersDetails(listbp);
	 * dp.setInternalShipmentId(generatedInternalShipmentId); return dp; }
	 */

	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/createNewShipment") public boolean
	 * createNewShipment(@RequestBody CreateNewShipmentDto dto) { boolean flag =
	 * false; Date date = new Date(); SimpleDateFormat formatter = new
	 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); String strDate =
	 * formatter.format(date);
	 * 
	 * // CreateNewShipmentDto dto1 = null; Shipments shipment = new Shipments();
	 * ShipmentTransactions shipmentTxns = new ShipmentTransactions(); Shipments
	 * shipments = shiprepo.findByShipment_Id(dto.getShipment_Number()); //
	 * List<ShipmentTransactions> shipmentTxnsList = //
	 * shiptransrepo.findByShipment_Id(dto.getShipment_Number()); try { if
	 * (shipments.getShipment_Id().equals(dto.getShipment_Number())) {
	 * shipmentTxns.setCustomer_Id(dto.getCustomerId());
	 * shipmentTxns.setShipment_Id(dto.getShipment_Number());
	 * shipmentTxns.setDevice_Id(dto.getDeviceId());
	 * shipmentTxns.setPartner_From(dto.getParnterFrom());
	 * shipmentTxns.setPartner_To(dto.getPartnerTo());
	 * shipmentTxns.setEvent_Name(dto.getEventName());
	 * shipmentTxns.setEvent_Exec_Date(dto.getDateAndTime());
	 * shipmentTxns.setComments(dto.getComments());
	 * shipmentTxns.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
	 * shipmentTxns.setEvent_Status("INITIALIZED");
	 * shipmentTxns.setExpected_Date_At_BP(strDate);
	 * shipmentTxns.setShip_Date_From_BP(strDate);
	 * shiptransrepo.insert(shipmentTxns); flag = true; System.out.
	 * println("shipment id alredy exists so saved the Events in shipment Txns Collection"
	 * ); return flag; } } catch (Exception e) {
	 * 
	 * }
	 * 
	 * shipment.setCustomer_Id(dto.getCustomerId());
	 * shipment.setShipment_Id(dto.getShipment_Number());
	 * shipment.setType_Of_Reference(dto.getTypeOfReference());
	 * shipment.setComments(dto.getComments());
	 * shipment.setRoute_Id(dto.getRouteId());
	 * shipment.setRoute_From(dto.getRouteFrom());
	 * shipment.setRoute_To(dto.getRouteTo());
	 * shipment.setGoods_Id(dto.getGoodsId());
	 * shipment.setGoods_Desc(dto.getGoodsType());
	 * shipment.setEstimated_Delivery_Date(dto.getEstimatedDeliveryDate());
	 * shipment.setCreated_By(dto.getParnterFrom());
	 * shipment.setDevice_Id(dto.getDeviceId()); shipment.setCreated_Date(strDate);
	 * shipment.setInternalShipmentId(dto.getInternalShipmentId());
	 * shiprepo.insert(shipment);
	 * System.out.println("Data persisted in Shipment Collections");
	 * 
	 * shipmentTxns.setCustomer_Id(dto.getCustomerId());
	 * shipmentTxns.setShipment_Id(dto.getShipment_Number());
	 * shipmentTxns.setDevice_Id(dto.getDeviceId());
	 * shipmentTxns.setPartner_From(dto.getParnterFrom());
	 * shipmentTxns.setPartner_To(dto.getPartnerTo());
	 * shipmentTxns.setEvent_Name(dto.getEventName());
	 * shipmentTxns.setEvent_Exec_Date(dto.getDateAndTime());
	 * shipmentTxns.setComments(dto.getComments());
	 * shipmentTxns.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
	 * shipmentTxns.setEvent_Status("INITIALIZED");
	 * shipmentTxns.setExpected_Date_At_BP(strDate);
	 * shipmentTxns.setShip_Date_From_BP(strDate);
	 * shiptransrepo.insert(shipmentTxns);
	 * System.out.println("data persisted in ShipmentTrans collection"); flag =
	 * true; return flag;
	 * 
	 * }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/createNewShipment") public boolean
	 * createNewShipment(@RequestBody CreateNewShipmentDto dto) { boolean flag =
	 * false; Date date = new Date(); SimpleDateFormat formatter = new
	 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); String strDate =
	 * formatter.format(date); Shipments shipment = new Shipments();
	 * ShipmentTransactions shipmentTxns1; ShipmentTransactions shipmentTxns2;
	 * Shipments shipments = shiprepo.findByShipment_Id(dto.getShipment_Number());
	 * try { if (shipments.getShipment_Id().equals(dto.getShipment_Number())) { for
	 * (AllEvents events : dto.getAllEvents()) { shipmentTxns2 = new
	 * ShipmentTransactions(); shipmentTxns2.setCustomer_Id(dto.getCustomerId());
	 * shipmentTxns2.setShipment_Id(dto.getShipment_Number());
	 * shipmentTxns2.setDevice_Id(dto.getDeviceId());
	 * shipmentTxns2.setPartner_From(events.getPartner());
	 * shipmentTxns2.setEvent_Id(events.getEvent_Id());
	 * shipmentTxns2.setPartner_To(dto.getPartnerTo());
	 * shipmentTxns2.setEvent_Name(events.getEvent());
	 * shipmentTxns2.setEvent_Exec_Date(dto.getDateAndTime());
	 * shipmentTxns2.setComments(dto.getComments());
	 * shipmentTxns2.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
	 * shipmentTxns2.setEvent_Status("INITIALIZED");
	 * shipmentTxns2.setExpected_Date_At_BP(strDate);
	 * shipmentTxns2.setShip_Date_From_BP(strDate);
	 * shiptransrepo.insert(shipmentTxns2); flag = true; System.out.
	 * println("shipment id alredy exists so saved the Events in shipment Txns Collection"
	 * ); // return flag;
	 * 
	 * }
	 * 
	 * } } catch (Exception e) {
	 * 
	 * } shipment.setCustomer_Id(dto.getCustomerId());
	 * shipment.setShipment_Id(dto.getShipment_Number());
	 * shipment.setType_Of_Reference(dto.getTypeOfReference());
	 * shipment.setComments(dto.getComments());
	 * shipment.setRoute_Id(dto.getRouteId());
	 * shipment.setRoute_From(dto.getRouteFrom());
	 * shipment.setRoute_To(dto.getRouteTo());
	 * shipment.setGoods_Id(dto.getGoodsId());
	 * shipment.setGoods_Desc(dto.getGoodsType());
	 * shipment.setEstimated_Delivery_Date(dto.getEstimatedDeliveryDate());
	 * shipment.setCreated_By(dto.getParnterFrom());
	 * shipment.setDevice_Id(dto.getDeviceId());
	 * shipment.setIncoTerms(dto.getIncoTerms()); shipment.setMode(dto.getMode());
	 * shipment.setTemp(dto.getTemp()); shipment.setRH(dto.getRH());
	 * shipment.setCreated_Date(strDate);
	 * shipment.setShipment_Num(dto.getShipment_Num()); shiprepo.insert(shipment);
	 * System.out.println("Data persisted in Shipment Collections");
	 * 
	 * for (AllEvents events : dto.getAllEvents()) { shipmentTxns1 = new
	 * ShipmentTransactions(); shipmentTxns1.setCustomer_Id(dto.getCustomerId());
	 * shipmentTxns1.setShipment_Id(dto.getShipment_Number());
	 * shipmentTxns1.setDevice_Id(dto.getDeviceId());
	 * shipmentTxns1.setPartner_From(events.getPartner());
	 * shipmentTxns1.setEvent_Id(events.getEvent_Id());
	 * shipmentTxns1.setPartner_To(dto.getPartnerTo());
	 * shipmentTxns1.setEvent_Name(events.getEvent());
	 * shipmentTxns1.setEvent_Exec_Date(dto.getDateAndTime());
	 * shipmentTxns1.setComments(dto.getComments());
	 * shipmentTxns1.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
	 * shipmentTxns1.setEvent_Status("INITIALIZED");
	 * shipmentTxns1.setExpected_Date_At_BP(strDate);
	 * shipmentTxns1.setShip_Date_From_BP(strDate);
	 * shiptransrepo.insert(shipmentTxns1); flag = true; System.out.
	 * println("shipment id alredy exists so saved the Events in shipment Txns Collection"
	 * ); // return flag;
	 * 
	 * } return flag; }
	 */

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/createNewShipment")
	public Response createNewShipment(@Validated @RequestBody CreateNewShipmentDto dto) throws Exception {
		Response resp = new Response();
		// boolean flag = false;
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String strDate = formatter.format(date);
		Shipments shipment = new Shipments();
		ShipmentTransactions shipmentTxns1;
		ShipmentTransactions shipmentTxns2;
		Shipments shipments = shiprepo.findByShipment_Id(dto.getShipment_Number());
		try {
			if (shipments.getShipment_Id().equals(dto.getShipment_Number())) {
				for (AllEvents events : dto.getAllEvents()) {
					shipmentTxns2 = new ShipmentTransactions();
					shipmentTxns2.setCustomer_Id(dto.getCustomerId());
					shipmentTxns2.setShipment_Id(dto.getShipment_Number());
					shipmentTxns2.setShipment_Num(dto.getShipment_Num());
					shipmentTxns2.setDevice_Id(dto.getDeviceId());
					shipmentTxns2.setPartner(events.getBp_Id());
					shipmentTxns2.setPartner_From(events.getPartner());
					shipmentTxns2.setEvent_Id(events.getEvent_Id());
					shipmentTxns2.setPartner_To(dto.getPartnerTo());
					shipmentTxns2.setEvent_Name(events.getEvent());
					shipmentTxns2.setEvent_Exec_Date(dto.getDateAndTime());
					shipmentTxns2.setComments(dto.getComments());
					shipmentTxns2.setMode_of_Transport(dto.getMode());
					shipmentTxns2.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
					shipmentTxns2.setEvent_Status("");
					shipmentTxns2.setExpected_Date_At_BP(strDate);
					shipmentTxns2.setShip_Date_From_BP(strDate);
					shiptransrepo.insert(shipmentTxns2);
					resp.setMessage("shipment id alredy exists so saved the Events in shipment Txns Collection");
					resp.setStatus(true);

					return resp;

				}
			}
		} catch (Exception e) {

		}
		shipment.setCustomer_Id(dto.getCustomerId());
		shipment.setInternalShipmentId(dto.getInternalShipmentId());
		shipment.setShipment_Id(dto.getShipment_Number());
		shipment.setShipment_Num(dto.getShipment_Num());
		shipment.setType_Of_Reference(dto.getTypeOfReference());
		shipment.setComments(dto.getComments());
		shipment.setRoute_Id(dto.getRouteId());
		shipment.setRoute_From(dto.getRouteFrom());
		shipment.setRoute_To(dto.getRouteTo());
		shipment.setGoods_Id(dto.getGoodsId());
		shipment.setGoods_Desc(dto.getGoodsType());
		shipment.setEstimated_Delivery_Date(dto.getEstimatedDeliveryDate());
		shipment.setCreated_By(dto.getParnterFrom());
		shipment.setDevice_Id(dto.getDeviceId());
		shipment.setIncoTerms(dto.getIncoTerms());
		shipment.setMode(dto.getMode());
		shipment.setTemp(dto.getTemp());
		shipment.setRH(dto.getRH());
		shipment.setPartner(dto.getPartner());
		shipment.setShipment_Status(dto.getEvent());
		shipment.setDelivered_Date(dto.getDatee());
		shipment.setCreated_Date(strDate);
		shipment.setPo_Number(dto.getPo_Number());
		shipment.setNdc_Number(dto.getNdc_Number());
		shipment.setInvoice_Number(dto.getInvoice_Number());
		shipment.setShipper_Number(dto.getShipper_Number());
		shipment.setSerial_Number_of_goods(dto.getSerial_Number_of_goods());
		shipment.setBatch_Id(dto.getBatch_Id());
		shipment.setCmo_Ref_Number(dto.getCmo_Ref_Number());

		try {
			if (!dto.getInternalShipmentId().equals(null)) {
				shipment.setInternalShipmentId(generateInternalShipmentId());
			}
		} catch (NullPointerException e) {
			shipment.setInternalShipmentId(generateInternalShipmentId());
		}
		shiprepo.insert(shipment);
		Query query = new Query();
		query.addCriteria(new Criteria().andOperator(Criteria.where("Device_Id").is(dto.getDeviceId())));
		Update update = new Update();
		update.set("DeviceStatusReferred", "Attached To Shipment");
		mongoTemplate.updateMulti(query, update, "Devices");
		System.out.println("Data persisted in Shipment Collections" + dto.getAllEvents());

		for (AllEvents events : dto.getAllEvents()) {
			System.out.println("Events::::" + events.getEvent_Id());

			shipmentTxns1 = new ShipmentTransactions();
			shipmentTxns1.setCustomer_Id(dto.getCustomerId());
			shipmentTxns1.setShipment_Id(dto.getShipment_Number());
			shipmentTxns1.setShipment_Num(dto.getShipment_Num());
			shipmentTxns1.setDevice_Id(dto.getDeviceId());
			shipmentTxns1.setPartner_From(events.getPartner());
			shipmentTxns1.setEvent_Id(events.getEvent_Id());

			shipmentTxns1.setPartner_To(dto.getPartnerTo());
			shipmentTxns1.setEvent_Name(events.getEvent());
			shipmentTxns1.setPartner(events.getBp_Id());
			shipmentTxns1.setEvidence(events.getEvidence());
			// shipmentTxns1.setEvent_Statusa(events.getEvent_Statusa());
			shipmentTxns1.setEvent_Exec_Date(dto.getDateAndTime());
			shipmentTxns1.setComments(dto.getComments());
			shipmentTxns1.setMode_of_Transport(dto.getMode());
			shipmentTxns1.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
			shipmentTxns1.setEvent_Status(events.getEvent_Status());
			shipmentTxns1.setExpected_Date_At_BP(strDate);
			shipmentTxns1.setShip_Date_From_BP(strDate);
			shiptransrepo.insert(shipmentTxns1);

			resp.setMessage("Shipment and Events Created Successfully");
			resp.setStatus(true);

		}
		return resp;
	}

	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/createNewShipment") public Response
	 * createNewShipment(@RequestBody CreateNewShipmentDto dto) throws Exception {
	 * 
	 * Response resp = new Response(); // resp.setStatus(false);
	 * 
	 * // String Status ="";
	 * 
	 * Date date = new Date(); SimpleDateFormat formatter = new
	 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); String strDate =
	 * formatter.format(date); Shipments shipment = new Shipments();
	 * ShipmentTransactions shipmentTxns1; ShipmentTransactions shipmentTxns2;
	 * Shipments shipments = shiprepo.findByShipment_Id(dto.getShipment_Number());
	 * 
	 * try { if (shipments.getShipment_Id().equals(dto.getShipment_Number())) {
	 * System.out.println("Hello Events"); for (AllEvents events :
	 * dto.getAllEvents()) { shipmentTxns2 = new ShipmentTransactions();
	 * shipmentTxns2.setCustomer_Id(dto.getCustomerId());
	 * shipmentTxns2.setShipment_Id(dto.getShipment_Number());
	 * shipmentTxns2.setShipment_Num(dto.getShipment_Num());
	 * shipmentTxns2.setDevice_Id(dto.getDeviceId());
	 * shipmentTxns2.setPartner_From(events.getPartner());
	 * shipmentTxns2.setEvent_Id(events.getEvent_Id());
	 * shipmentTxns2.setPartner_To(dto.getPartnerTo());
	 * shipmentTxns2.setEvidence(events.getEvidence());
	 * shipmentTxns2.setEvent_Name(events.getEvent());
	 * shipmentTxns2.setEvent_Exec_Date(dto.getDateAndTime());
	 * shipmentTxns2.setComments(dto.getComments());
	 * shipmentTxns2.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
	 * shipmentTxns2.setEvent_Status("");
	 * shipmentTxns2.setExpected_Date_At_BP(strDate);
	 * shipmentTxns2.setShip_Date_From_BP(strDate);
	 * shiptransrepo.insert(shipmentTxns2);
	 * 
	 * resp.setStatus(true); resp.setMessasge("Created Shipment Successfully");
	 * 
	 * return resp; // flag = true; // System.out.println("shipment id alredy exists
	 * so saved the Events in shipment // Txns Collection"); // return flag;
	 * 
	 * } } } catch (Exception e) {
	 * 
	 * // resp.setStatus(false); resp.setMessasge("ShipmentID Already exists");
	 * 
	 * // return resp;
	 * 
	 * } try { shipment.setCustomer_Id(dto.getCustomerId());
	 * shipment.setShipment_Id(dto.getInternalShipmentId());
	 * shipment.setShipment_Num(dto.getShipment_Num());
	 * shipment.setType_Of_Reference(dto.getTypeOfReference());
	 * shipment.setComments(dto.getComments());
	 * shipment.setRoute_Id(dto.getRouteId());
	 * shipment.setRoute_From(dto.getRouteFrom());
	 * shipment.setRoute_To(dto.getRouteTo());
	 * shipment.setGoods_Id(dto.getGoodsId());
	 * shipment.setGoods_Desc(dto.getGoodsType());
	 * shipment.setEstimated_Delivery_Date(dto.getEstimatedDeliveryDate());
	 * shipment.setCreated_By(dto.getParnterFrom());
	 * shipment.setDevice_Id(dto.getDeviceId());
	 * shipment.setIncoTerms(dto.getIncoTerms()); shipment.setMode(dto.getMode());
	 * shipment.setTemp(dto.getTemp()); shipment.setRH(dto.getRH());
	 * shipment.setPartner(dto.getPartner());
	 * shipment.setShipment_Status(dto.getEvent());
	 * shipment.setDelivered_Date(dto.getDatee());
	 * shipment.setCreated_Date(strDate); try { if
	 * (dto.getInternalShipmentId().equals("")) {
	 * shipment.setInternalShipmentId(generateInternalShipmentId()); } } catch
	 * (NullPointerException e) {
	 * shipment.setInternalShipmentId(generateInternalShipmentId()); }
	 * shiprepo.insert(shipment); Query query = new Query(); query.addCriteria(new
	 * Criteria().andOperator(Criteria.where("Device_Id").is(dto.getDeviceId())));
	 * Update update = new Update(); update.set("DeviceStatusReferred",
	 * "Attached To Shipment"); mongoTemplate.updateMulti(query, update, "Devices");
	 * System.out.println("Data persisted in Shipment Collections");
	 * System.out.println("hjskdgfsafksadf"+dto.getAllEvents()); for (AllEvents
	 * events : dto.getAllEvents()) { shipmentTxns1 = new ShipmentTransactions();
	 * shipmentTxns1.setCustomer_Id(dto.getCustomerId());
	 * shipmentTxns1.setShipment_Id(dto.getShipment_Number());
	 * shipmentTxns1.setShipment_Num(dto.getShipment_Num());
	 * shipmentTxns1.setDevice_Id(dto.getDeviceId());
	 * shipmentTxns1.setPartner_From(events.getPartner());
	 * shipmentTxns1.setEvent_Id(events.getEvent_Id());
	 * shipmentTxns1.setPartner_To(dto.getPartnerTo());
	 * shipmentTxns1.setEvent_Name(events.getEvent());
	 * shipmentTxns1.setEvidence(events.getEvidence());
	 * shipmentTxns1.setEvent_Statusa(events.getEvent_Statusa());
	 * shipmentTxns1.setEvent_Exec_Date(dto.getDateAndTime());
	 * shipmentTxns1.setComments(dto.getComments());
	 * shipmentTxns1.setEvent_SNo(evendiddao.getNextSequenceId(HOSTING_SEQ_KEY));
	 * shipmentTxns1.setEvent_Status("");
	 * shipmentTxns1.setExpected_Date_At_BP(strDate);
	 * shipmentTxns1.setShip_Date_From_BP(strDate);
	 * shiptransrepo.insert(shipmentTxns1); resp.setStatus(true);
	 * resp.setMessasge("Created Shipment and Events Successfully"); System.out.
	 * println("shipment id alredy exists so saved the Events in shipment Txns Collection"
	 * ); return resp;
	 * 
	 * } } catch (Exception e) {
	 * 
	 * // TODO: handle exception } return resp; }
	 */
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getEventId/{BP_Id}/{EventType}")
	public EventId getEventId(@PathVariable(value = "BP_Id") String BpId,
			@PathVariable(value = "EventType") String EventType) {
		EventId evId = new EventId();
		List<BusinessPartner> ev = new ArrayList<>();
		Criteria crt = new Criteria();
		crt.andOperator(Criteria.where("BP_Id").is(BpId));
		Query query = new Query(crt);
		ev = mongoTemplate.find(query, BusinessPartner.class);
		for (BusinessPartner bp : ev) {
			for (Events e : bp.getEvents()) {
				if (e.getEvent_Status().equals(EventType)) {
					evId.setEvent_Id(e.getEvent_Id());
					evId.setEvent_Status(e.getEvent_Status());
				}
			}
		}
		return evId;
	}

	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/saveDraft") public boolean saveShipmentDraft(@RequestBody
	 * ShipmentDraftDto dto) { boolean flag = false; ShipmentDraftDto draft = null;
	 * 
	 * try { ShipmentDraftDto internalId =
	 * saveShipDraftsRepo.findByInternal_Shipment_id(dto.getInternal_Shipment_Id());
	 * if
	 * (internalId.getInternal_Shipment_Id().equals(dto.getInternal_Shipment_Id()))
	 * { System.out.println("Draft with the Internal Shipmet Id alredy exists");
	 * flag = false; return flag; } } catch (Exception e) {
	 * System.out.println(e.getMessage()); } draft = new ShipmentDraftDto();
	 * draft.setInternal_Shipment_Id(dto.getInternal_Shipment_Id());
	 * draft.setCustomerId(dto.getCustomerId());
	 * draft.setShipment_Number(dto.getShipment_Number());
	 * draft.setTypeOfReference(dto.getTypeOfReference());
	 * draft.setComments(dto.getComments()); draft.setRouteId(dto.getRouteId());
	 * draft.setRouteFrom(dto.getRouteFrom()); draft.setRouteTo(dto.getRouteTo());
	 * draft.setGoodsId(dto.getGoodsId()); draft.setGoodsType(dto.getGoodsType());
	 * draft.setDeviceId(dto.getDeviceId());
	 * draft.setEstimatedDeliveryDate(dto.getEstimatedDeliveryDate());
	 * draft.setParnterFrom(dto.getParnterFrom());
	 * draft.setPartnerTo(dto.getPartnerTo());
	 * draft.setEventName(dto.getEventName());
	 * draft.setDateAndTime(dto.getDateAndTime());
	 * draft.setIncoterms(dto.getIncoterms()); savedraftRepo.insert(draft); flag =
	 * true;
	 * 
	 * return flag; }
	 */
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/saveDraft")
	public boolean saveShipmentDraft(@Validated @RequestBody ShipmentDraftDto dto) {
		boolean flag = false;
		ShipmentDraftDto draft = null;

		try {
			ShipmentDraftDto internalId = saveShipDraftsRepo.findByInternal_Shipment_id(dto.getInternal_Shipment_Id());
			if (internalId.getInternal_Shipment_Id().equals(dto.getInternal_Shipment_Id())) {
				System.out.println("Draft with the Internal Shipmet Id alredy exists");
				flag = false;
				return flag;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		draft = new ShipmentDraftDto();
		draft.setInternal_Shipment_Id(dto.getInternal_Shipment_Id());
		draft.setCustomer_Id(dto.getCustomer_Id());
		draft.setShipment_Number(dto.getShipment_Number());
		draft.setTypeOfReference(dto.getTypeOfReference());
		draft.setComments(dto.getComments());
		draft.setRouteId(dto.getRouteId());
		draft.setRouteFrom(dto.getRouteFrom());
		draft.setRouteTo(dto.getRouteTo());
		draft.setGoodsId(dto.getGoodsId());
		draft.setGoodsType(dto.getGoodsType());
		// draft.setDeviceId(dto.getDeviceId());
		draft.setEstimatedDeliveryDate(dto.getEstimatedDeliveryDate());
		draft.setParnterFrom(dto.getParnterFrom());
		draft.setPartnerTo(dto.getPartnerTo());
		draft.setEventName(dto.getEventName());
		draft.setDateAndTime(dto.getDateAndTime());
		draft.setInco(dto.getInco());

		draft.setRouteInfo(dto.getRouteInfo());
		draft.setMode(dto.getMode());
		draft.setSelectEventId(dto.getSelectEventId());
		draft.setPo_Number(dto.getPo_Number());
		draft.setNdc_Number(dto.getNdc_Number());
		draft.setInvoice_Number(dto.getInvoice_Number());
		draft.setShipper_Number(dto.getShipper_Number());
		draft.setSerial_Number_of_goods(dto.getSerial_Number_of_goods());
		draft.setBatch_Id(dto.getBatch_Id());
		savedraftRepo.insert(draft);
		flag = true;

		return flag;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/deleteDraft/{Internal_Shipment_Id}")
	public boolean deleteDraft(@PathVariable(value = "Internal_Shipment_Id") String Internal_Shipment_Id) {
		boolean flag = false;
		try {
			Query query = new Query();
			query.addCriteria(Criteria.where("Internal_Shipment_Id").is(Internal_Shipment_Id));
			mongoTemplate.findAndRemove(query, ShipmentDraftDto.class);
			System.out.println("removed");
			flag = true;
			return flag;

		} catch (Exception e) {
			// TODO: handle exception
		}
		return flag;
	}

	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/deleteGoodItem/{Customer_Id}") public Customer
	 * deleteGoodItem(@PathVariable(value = "Customer_Id") String
	 * Customer_Id,@PathVariable(value = "Good_Id") Goods Good_Id) {
	 * 
	 * // Update update = new Update().pull("Goods", new //
	 * BasicDBObject("Goods.Goods_Id",Good_Id)); // mongoTemplate.updateMulti(new
	 * Query(), update, Goods.class);
	 * 
	 * 
	 * Query query = new Query();
	 * query.addCriteria(Criteria.where("Customer_Id").is(Good_Id));
	 * mongoTemplate.findAndRemove(query, Goods.class);
	 * System.out.println("removed");
	 * 
	 * return customerepo.findByCustomerId(Customer_Id.trim());
	 * 
	 * 
	 * }
	 */
	// public GetService to get the DetailsOfTheAllTheShipmentTransaction which
	// are associated with ShipmentId and BuspartId

	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDeviceDataTemp/{Shipment_Id}") public List<DeviceDataStream>
	 * getDeviceDataTemp(@PathVariable(value = "Shipment_Id") String Shipment_Id) {
	 * Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id); String deviceId
	 * = shipment.getDevice_Id();
	 * 
	 * String createdDate = shipment.getCreated_Date();
	 * System.out.println(deviceId); List<DeviceDataStream> deviceDataStrem = null;
	 * try { deviceDataStrem = devicedatarepo.getDeviceDataStream(deviceId.trim(),
	 * createdDate.trim()); System.out.println(deviceDataStrem); } catch (Exception
	 * e) { } return deviceDataStrem; }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDeviceDataTemp/{Shipment_Id}") public List<Devicedatatemp>
	 * getDeviceDataTemp(@PathVariable(value = "Shipment_Id") String Shipment_Id) {
	 * Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id); String deviceId
	 * = shipment.getDevice_Id(); System.out.println(deviceId);
	 * List<DeviceDataStream> deviceDataStrem1 = null; List<Devicedatatemp> devlist
	 * = new ArrayList<>(); String Humidity = null; // String
	 * Internal_Temperature=null; String deviceDataStream1 = ""; try {
	 * 
	 * deviceDataStrem1 = devicedatarepo.findByDevice_id(deviceId);
	 * 
	 * for (DeviceDataStream dv : deviceDataStrem1) { Devicedatatemp temphum = new
	 * Devicedatatemp();
	 * 
	 * if (dv.getMessageType().equals("sensor")) {
	 * System.out.println("shadgasjhgdfjasg" + dv.getUTC());
	 * temphum.setHumidity(dv.getHumidity_1()); temphum.setUTC(dv.getUTC());
	 * temphum.setDevice_Id(dv.getDevice_Id());
	 * temphum.setInternal_Temperature(dv.getInternal_temperature());
	 * devlist.add(temphum);
	 * 
	 * } }
	 * 
	 * // deviceDataStrem = devicedatarepo.getInternalTemp(deviceId) //
	 * System.out.println(deviceDataStrem); } catch (Exception e) { } return
	 * devlist; }
	 */

	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDeviceDataTemp/{Shipment_Id}") public List<Devicedatatemp>
	 * getDeviceDataTemp(@PathVariable(value = "Shipment_Id") String Shipment_Id) {
	 * Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id); String deviceId
	 * = shipment.getDevice_Id(); String created_date = shipment.getCreated_Date();
	 * System.out.println("Created Date::::" + created_date);
	 * System.out.println(deviceId); List<DeviceDataStream> deviceDataStrem1 = null;
	 * List<Devicedatatemp> devlist = new ArrayList<>(); String Humidity = null; //
	 * String Internal_Temperature=null; String deviceDataStream1 = ""; try {
	 * 
	 * deviceDataStrem1 = devicedatarepo.findByDevice_id(deviceId);
	 * 
	 * for (DeviceDataStream dv : deviceDataStrem1) { Devicedatatemp temphum = new
	 * Devicedatatemp();
	 * 
	 * if (dv.getMessageType().equals("sensor")) { if
	 * (dv.getSensorUTC().compareTo(created_date) > 0) {
	 * System.out.println("DeviceUTC::::" + dv.getSensorUTC());
	 * 
	 * temphum.setUTC(dv.getSensorUTC()); // System.out.println("shadgasjhgdfjasg");
	 * temphum.setHumidity(dv.getHumidity_1());
	 * temphum.setInternal_Temperature(dv.getInternal_temperature());
	 * 
	 * devlist.add(temphum); }
	 * 
	 * } }
	 * 
	 * // deviceDataStrem = devicedatarepo.getInternalTemp(deviceId) //
	 * System.out.println(deviceDataStrem); } catch (Exception e) { } return
	 * devlist; }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/completeNewShipment") public boolean
	 * completeNewShipment(@RequestBody CompleteShipment shipment) { boolean flag =
	 * false; Date date = new Date(); SimpleDateFormat formatter = new
	 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); String strDate =
	 * formatter.format(date); List<ShipmentTransactions> list =
	 * shiptransrepo.findByPartner_from(shipment.getPartnerFrom()); try { for
	 * (ShipmentTransactions list1 : list) { if
	 * (list1.getShipment_Id().equals(shipment.getShipment_Number())) { if
	 * (list1.getPartner_From().equals(shipment.getPartnerFrom())) { if
	 * (list1.getEvent_Name().equals(shipment.getEventType())) { Query query = new
	 * Query(); query.addCriteria(new Criteria().andOperator(
	 * Criteria.where("Shipment_Id").is(shipment.getShipment_Number()),
	 * Criteria.where("Partner_From").is(shipment.getPartnerFrom()),
	 * Criteria.where("Event_Name").is(shipment.getEventType()))); Update update =
	 * new Update(); update.set("Partner_To", shipment.getReceivingLocation());
	 * update.set("EventReferenceNumber", shipment.getReceivingReferenceNumber());
	 * update.set("TypeOfReference", shipment.getTypeOfReference());
	 * mongoTemplate.updateMulti(query, update, "ShipmentTransactions"); System.out.
	 * println("Completed Shipment with Receiving Refrence Number Updated : " +
	 * list1.getEvent_SNo()); flag = true; }
	 * 
	 * } } } } catch (Exception e) { // TODO: handle exception } // Updating Device
	 * Return Location in Shipments if (flag == true) { Query query = new
	 * Query(Criteria.where("Shipment_Id").is(shipment.getShipment_Number()));
	 * Update update = new Update(); update.set("DeviceReturnLocation",
	 * shipment.getDeviceReturnLocation()); update.set("Delivered_Date", strDate);
	 * update.set("Type_Of_Reference", shipment.getTypeOfReference());
	 * mongoTemplate.updateMulti(query, update, "Shipments"); System.out.
	 * println("Updated Device Return Location in the Shipments Collection"); return
	 * flag = true; } return flag; }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDeviceDataTemp/{Shipment_Id}") public List<Devicedatatemp>
	 * getDeviceDataTemp(@PathVariable(value = "Shipment_Id") String Shipment_Id) {
	 * Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id); String
	 * deliveryNo = shipment.getShipment_Num(); String deviceId =
	 * shipment.getDevice_Id(); String created_date = shipment.getCreated_Date();
	 * List<DeviceDataStream> deviceDataStrem1 = null; List<Devicedatatemp> devlist
	 * = new ArrayList<>(); String Humidity = null;
	 * 
	 * String deviceDataStream1 = ""; try {
	 * 
	 * deviceDataStrem1 = devicedatarepo.findByDevice_id(deviceId);
	 * 
	 * for (DeviceDataStream dv : deviceDataStrem1) { Devicedatatemp temphum = new
	 * Devicedatatemp();
	 * 
	 * if (dv.getMessageType().equals("sensor")) { if
	 * (dv.getSensorUTC().compareTo(created_date) > 0) {
	 * 
	 * temphum.setDevice_Id(dv.getDevice_Id()); temphum.setShipment_Num(deliveryNo);
	 * temphum.setUTC(dv.getSensorUTC()); temphum.setHumidity(dv.getHumidity_1());
	 * temphum.setInternal_Temperature(dv.getInternal_temperature());
	 * 
	 * devlist.add(temphum); }
	 * 
	 * } }
	 * 
	 * } catch (Exception e) { } return devlist; }
	 */
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getDeviceDataTemp/{Shipment_Id}")
	public List<Devicedatatemp> getDeviceDataTemp(@PathVariable(value = "Shipment_Id") String Shipment_Id) throws ParseException {
		Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id);
		String deliveryNo = shipment.getShipment_Num();
		String deviceId = shipment.getDevice_Id();
		System.out.println("Deviceidssssss::::" + deviceId);
		String created_date = shipment.getCreated_Date();
		// List<DeviceDataStream> deviceDataStrem1 = null;
		List<Devicedatatemp> devlist = new ArrayList<>();
		// List<DeviceDataStream> response = new ArrayList<>();
		String Humidity = null;
		AggregationResults<DeviceDataStream> results = null;
		String deviceDataStream1 = "";
		//try {

			SimpleDateFormat sdfSource = new SimpleDateFormat("yyyy-MM-dd");

			Date date = sdfSource.parse(created_date.split("T")[0]);

			// create SimpleDateFormat object with desired date format
			SimpleDateFormat sdfDestination = new SimpleDateFormat("MM/dd/yy");
			// deviceDataStrem1 = devicedatarepo.findByDevice_id(deviceId);
			System.out.println("Device id " + deviceId);
			// AggregationOperation match1 =
			// Aggregation.match(Criteria.where("Device_Id").is(deviceId));
//			AggregationOperation match1 = Aggregation.match(
//					Criteria.where("Device_Id").is(deviceId).andOperator(Criteria.where("Message_Type").is("sensor")).orOperator(Criteria.where("Message_Type").is("GPS MESSAGE")));
//
//			AggregationOperation sort = Aggregation.sort(Sort.Direction.ASC, "current_terminal_date");
//		//	AggregationOperation sort1 = Aggregation.sort(Sort.Direction.ASC, "current_terminal_time");
			AggregationOperation match1 = Aggregation.match(Criteria.where("Device_Id").is(deviceId)
					.andOperator(Criteria.where("current_terminal_date").gte(sdfDestination.format(date))));

			// System.out.println("sort " + sort);

			Aggregation aggregation = Aggregation.newAggregation(match1);
			System.out.println("aggregation " + aggregation);
			results = mongoTemplate.aggregate(aggregation, "DeviceDataStream", DeviceDataStream.class);
//System.out.println("results "+results);
			String temAddress = "";
			String maxTempThresh=shipment.getTemp().split("-")[1].trim().replace(" c", "");
			String minTempThresh=shipment.getTemp().split("-")[0];
			for (DeviceDataStream dv : results) {
				Devicedatatemp temphum = new Devicedatatemp();
//System.out.println("in device data "+dv.getCurrent_terminal_date());
//System.out.println("dv.getMessage_Type() "+dv.getMessage_Type());
				if (dv.getMessage_Type().equals("GPS MESSAGE")) {
					temAddress = dv.getAddress();
				//	System.out.println("inside gps");
				} else if (dv.getMessage_Type().equals("sensor")) {
				//	System.out.println("inside sensor");
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yy");
					LocalDate date1 = LocalDate.parse(dv.getCurrent_terminal_date(), formatter);
					String dateTime = date1.toString() + "T" + dv.getCurrent_terminal_time() + ".000Z";
					if (dateTime.compareTo(created_date) > 0) {
						// System.out.println("after sensor utc comp :::::::::::"+dv);
						// System.out.println("Comparison " + dateTime + ":::::::" + created_date);
						temphum.setDevice_Id(dv.getDevice_Id());
						temphum.setShipment_Num(deliveryNo);
						temphum.setUTC(dateTime);
						temphum.setHumidity(dv.getHumidity_1());
						temphum.setInternal_Temperature(dv.getFirst_Sensor_temperature());
						temphum.setSensorTemp(dv.getFirst_Sensor_temperature());
						temphum.setMaxTempThresh(maxTempThresh);
						temphum.setMinTempThresh(minTempThresh);
						if (!dv.getAddress() .isEmpty()) {
							temAddress=dv.getAddress();
							//temphum.setAddress(temAddress);
						}
						temphum.setAddress(temAddress);
						devlist.add(temphum);
					}
				}

			}

			Collections.sort(devlist, Devicedatatemp.uTCComparator);

			// }
//		}
//
//		catch (Exception e) {
//			System.out.println("exception e "+e);
//		}
		return devlist;
	}
	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/completeNewShipment") public Response
	 * completeNewShipment(@RequestBody CompleteShipment shipment) { Response resp =
	 * new Response(); // resp.setStatus(false);
	 * 
	 * boolean flag = false; Date date = new Date(); SimpleDateFormat formatter =
	 * new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); String strDate =
	 * formatter.format(date); List<ShipmentTransactions> list =
	 * shiptransrepo.findByPartner_from(shipment.getPartnerFrom()); try { for
	 * (ShipmentTransactions list1 : list) { if
	 * (list1.getShipment_Id().equals(shipment.getShipment_Number())) { if
	 * (list1.getPartner_From().equals(shipment.getPartnerFrom())) { if
	 * (list1.getEvent_Name().equals(shipment.getEventType())) { Query query = new
	 * Query(); query.addCriteria(new Criteria().andOperator(
	 * Criteria.where("Shipment_Id").is(shipment.getShipment_Number()),
	 * Criteria.where("Partner_From").is(shipment.getPartnerFrom()),
	 * Criteria.where("Event_Name").is(shipment.getEventType()))); Update update =
	 * new Update(); update.set("Partner_To", shipment.getReceivingLocation());
	 * update.set("EventReferenceNumber", shipment.getReceivingReferenceNumber());
	 * update.set("TypeOfReference", shipment.getTypeOfReference());
	 * update.set("Event_Status","Completed"); mongoTemplate.updateMulti(query,
	 * update, "ShipmentTransactions"); System.out.
	 * println("Completed Shipment with Receiving Refrence Number Updated : " +
	 * list1.getEvent_SNo()); flag = true; // resp.setStatus(true); }
	 * 
	 * } } } } catch (Exception e) { // TODO: handle exception } // Updating Device
	 * Return Location in Shipments if (flag == true) { Query query = new
	 * Query(Criteria.where("Shipment_Id").is(shipment.getShipment_Number()));
	 * Update update = new Update(); update.set("DeviceReturnLocation",
	 * shipment.getDeviceReturnLocation()); update.set("Delivered_Date", strDate);
	 * update.set("Type_Of_Reference", shipment.getTypeOfReference());
	 * update.set("Shipment_Status", "Delivered");
	 * 
	 * mongoTemplate.updateMulti(query, update, "Shipments"); System.out.
	 * println("Updated Device Return Location in the Shipments Collection");
	 * resp.setMessage("Completed the Shipment successfully"); return resp; }
	 * resp.setMessage("Shipment Not yet Completed"); return resp; }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/completeNewShipment") public Response
	 * completeNewShipment(@RequestBody CompleteShipment shipment) { Response resp =
	 * new Response(); //resp.setStatus(false);
	 * 
	 * boolean flag = false; Date date = new Date(); SimpleDateFormat formatter =
	 * new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); String strDate =
	 * formatter.format(date); List<ShipmentTransactions> list =
	 * shiptransrepo.findByPartner_from(shipment.getPartnerFrom()); try { for
	 * (ShipmentTransactions list1 : list) { if
	 * (list1.getShipment_Id().equals(shipment.getShipment_Number())) { if
	 * (list1.getPartner_From().equals(shipment.getPartnerFrom())) { if
	 * (list1.getEvent_Name().equals(shipment.getEventType())) { Query query = new
	 * Query(); query.addCriteria(new Criteria().andOperator(
	 * Criteria.where("Shipment_Id").is(shipment.getShipment_Number()),
	 * Criteria.where("Partner_From").is(shipment.getPartnerFrom()),
	 * Criteria.where("Event_Name").is(shipment.getEventType()))); Update update =
	 * new Update(); update.set("Partner_To", shipment.getReceivingLocation());
	 * update.set("EventReferenceNumber", shipment.getReceivingReferenceNumber());
	 * update.set("TypeOfReference", shipment.getTypeOfReference());
	 * update.set("Event_Status", "Completed"); mongoTemplate.updateMulti(query,
	 * update, "ShipmentTransactions"); System.out.
	 * println("Completed Shipment with Receiving Refrence Number Updated : " +
	 * list1.getEvent_SNo());
	 * 
	 * flag = true; //resp.setStatus(true); }
	 * 
	 * } } } } catch (Exception e) { // TODO: handle exception } // Updating Device
	 * Return Location in Shipments if (flag == true) { Query query = new
	 * Query(Criteria.where("Shipment_Id").is(shipment.getShipment_Number()));
	 * Update update = new Update(); update.set("DeviceReturnLocation",
	 * shipment.getDeviceReturnLocation()); update.set("Delivered_Date", strDate);
	 * update.set("Type_Of_Reference", shipment.getTypeOfReference());
	 * update.set("Shipment_Status", "Delivered"); mongoTemplate.updateMulti(query,
	 * update, "Shipments"); System.out.
	 * println("Updated Device Return Location in the Shipments Collection");
	 * resp.setMessage("Completed the Shipment successfully"); resp.setStatus(true);
	 * return resp; } resp.setMessage("Shipment Not yet Completed");
	 * resp.setStatus(false); return resp; }
	 */

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/completeNewShipment")
	public Response completeNewShipment(@Validated @RequestBody CompleteShipment shipment)
			throws ParseException, FileNotFoundException, IOException, DocumentException {
		Response resp = new Response();
		// resp.setStatus(false);

		boolean flag = false;
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String strDate = formatter.format(date);
		List<ShipmentTransactions> list = shiptransrepo.findByPartner_from(shipment.getPartnerFrom());
		//System.out.println(list);
		try {
			for (ShipmentTransactions list1 : list) {
				if (list1.getShipment_Id().equals(shipment.getShipment_Number())) {
					System.out.println(shipment.getShipment_Number());
					if (list1.getPartner().equals(shipment.getPartner())) {
						if (list1.getEvent_Name().equals(shipment.getEvent())) {
							Query query = new Query();
							query.addCriteria(new Criteria().andOperator(
									Criteria.where("Shipment_Id").is(shipment.getShipment_Number()),
									Criteria.where("Partner").is(shipment.getPartner()),
									Criteria.where("Event_Name").is(shipment.getEvent())));
							Update update = new Update();
							update.set("Partner_To", shipment.getReceivingLocation());
							update.set("EventReferenceNumber", shipment.getReceivingReferenceNumber());
							update.set("TypeOfReference", shipment.getTypeOfReference());
							update.set("Event_Exec_Date", strDate);
							update.set("Evidence", shipment.getEvidence());
							update.set("EvidenceList", shipment.getEvidenceList());
							/*
							 * System.out.println("comments in transactions"+list1.getComments()[0]);
							 * System.out.println("comments in transactions"+list1.getComments()[1]);
							 */
							String[] cmnt = list1.getComments();
							List<String> cmnts = new ArrayList<String>();						
							for (int i = 0; i < cmnt.length; i++) {	 
								if (i < cmnt.length) {
									 cmnts.add(cmnt[i]);
								}								
							}
		//					System.out.println("the new comments are added"+   String.valueOf(shipment.getComments()));
							if(String.valueOf(shipment.getComments()).length() > 2 ) {
		//						System.out.println("Checking String Length "+String.valueOf(shipment.getComments()).length());
								cmnts.addAll(shipment.getComments());
							}
							update.set("Comments", cmnts);
			//				System.out.println("this is out of loop " +cmnts);														
							update.set("Event_Status", "Completed");
							mongoTemplate.updateMulti(query, update, "ShipmentTransactions");// to be
							// removed
							System.out.println("Completed Shipment with Receiving Refrence Number Updated : "
									+ list1.getEvent_SNo());

							flag = true;
							// resp.setStatus(true);
						}

					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		// Updating Device Return Location in Shipments
		if (flag == true) {
			Shipments shipfrom = shiprepo.findByShipment_Id(shipment.getShipment_Number());
			Query query = new Query(Criteria.where("Shipment_Id").is(shipment.getShipment_Number()));
			Update update = new Update();
			update.set("DeviceReturnLocation", shipment.getDeviceReturnLocation());
			update.set("Delivered_Date", strDate);
			update.set("Type_Of_Reference", shipment.getTypeOfReference());
			update.set("Shipment_Status", "Delivered");

			mongoTemplate.updateMulti(query, update, "Shipments");// to be removed
		//	cec.tempDataCalculator(shipfrom, strDate);
			//below method calls pdf email
	//		cec.tempDataCalculator(shipfrom, strDate,shipment.getGraphImage());
//			String pathFile="C:\\SMAASMailAttachments\\ShipmentImages\\"+shipment.getShipment_Number()+".png";
//			String base64url=shipment.getGraphImage().substring(shipment.getGraphImage().indexOf(",")+1);

			try  {
				
				//below method calls pdf email
				cec.tempDataCalculator(shipfrom, strDate,shipment.getGraphImage());
			} 
			catch (Exception e) {
				
				System.out.println("eror in tempdatacalculator " + e);
			}

			/********    below method triggers AWS Lambda Function for Outbound XML (data summary) file      *******/
			
		    final String AWS_ACCESS_KEY_ID = "AKIA23OBXAWH6GWFGYHN";
		    final String AWS_SECRET_ACCESS_KEY = "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";

		    AWSCredentials credentials = new BasicAWSCredentials(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY);

		    // ARN
		    String functionName = "arn:aws:lambda:us-east-2:746119955855:function:SCMXpert-OutboundFiles-Test";

		    //This will convert object to JSON String
//		    String inputJSON = new Gson().toJson(userActivity);
		    String inputJSON = "{\r\n"
		    		+ "  \"body\": {\r\n"
		    		+ "    \"internalShipmentNum\": \""+ shipment.getShipment_Number() +"\"\r\n"
		    		+ "  }\r\n"
		    		+ "}";
		    /*******    for static internal Shipment Number use the below string   ********/
//		    String inputJSON = "{\r\n"
//		    		+ "  \"body\": {\r\n"
//		    		+ "    \"internalShipmentNum\": \"T00000003\"\r\n"
//		    		+ "  }\r\n"
//		    		+ "}";

//		    String[] inputJSON = {"\"internalShipmentNum\": \"" + shipment.getShipment_Number() + "\",\r\n"
//		    		};			    
		    InvokeRequest lmbRequest = new InvokeRequest()
		            .withFunctionName(functionName)
		            .withPayload(inputJSON);
		    
		    lmbRequest.setInvocationType(InvocationType.RequestResponse);
		    
		    InvokeResult lmbResult = null;
            try {
            	
		          AWSLambda lambda = AWSLambdaClientBuilder.standard()
		            .withRegion(Regions.US_EAST_2)
		            .withCredentials(new AWSStaticCredentialsProvider(credentials)).build();
            //		.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:3001/","us-east-2"))
            //		.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("https://hgqefpcazjcktbwc6yehvshmvi0dxogj.lambda-url.us-east-2.on.aws/","us-east-2"))
		        
		          lmbResult = lambda.invoke(lmbRequest);

		          String resultJSON = new String(lmbResult.getPayload().array(), Charset.forName("UTF-8"));
		          //write out the return value
		          System.out.println("this is aws Lambda result" + resultJSON);
              }
				catch (ServiceException e) {
					
					System.out.println("eror in Lambda Method " + e);
				}
            
				System.out.println("Lambda Method Status Code " + lmbResult.getStatusCode());
				
       /***********     Lambda Request and Result/Response ends here      *************/
					
			Query query1 = new Query(Criteria.where("Device_Id").is(shipment.getConenctedDevice()));

			Update update1 = new Update();

			System.out.println("ghfvjgh" + shipment.getDeviceReturnLocation());
			if (shipment.getDeviceReturnLocation().equals("Same Location")) {
				System.out.println(shipment.getDeviceReturnLocation());
				update1.set("Device_Location", shipfrom.getRoute_To());
				update1.set("DeviceStatusReferred", "Available");
				mongoTemplate.updateMulti(query1, update1, "Devices");// to be removed

				System.out.println("Updated Device Return Location in the Shipments Collection");
				resp.setMessage("Completed the Shipment successfully");
				resp.setStatus(true);
				return resp;
			} else {
				update1.set("DeviceStatusReferred", "Detached");
				mongoTemplate.updateMulti(query1, update1, "Devices"); // to be removed
				System.out.println("Updated Device Return Location in the Shipments Collection");
				resp.setMessage("Completed the Shipment successfully");
				resp.setStatus(true);
				return resp;
			}
		}
		resp.setMessage("Shipment Not yet Completed");
		resp.setStatus(false);
		return resp;
	}
	
	
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getCompleteCalculations/{Shipment_Id}")
	public Calculations CompleteCalculations(@PathVariable(value = "Shipment_Id") String Shipment_Id) throws ParseException
	{
		Calculations cal = new Calculations();
		Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id);
		
		cal.setCustomerName(shipment.getPartner());
		cal.setPartnerName("SCMXpert");
		cal.setShipmentNo(shipment.getShipment_Num());
		cal.setShipmentDesc((shipment.getComments() == null
				? shipment.getGoods_Desc() + ", " + shipment.getRoute_From() + "-" + shipment.getRoute_To()
				: shipment.getComments()[0]));
		cal.setDeviceNo(shipment.getDevice_Id());
		cal.setRouteDetails(shipment.getRoute_From() + "-" + shipment.getRoute_To() + ", " + shipment.getMode());
					
		String deviceId = shipment.getDevice_Id();
		String created_date = shipment.getCreated_Date();
		
		Date datec = new Date();
		SimpleDateFormat formatterc = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String strDate = formatterc.format(datec);	
		String endDate = strDate;
//		String endDate = "2022-06-08T15:55:39.000Z";
// End Date should be within 365 days (because calculation in the method findDifference is written for 365 days) otherwise 
//the calculations would be wrong
		
		AggregationResults<DeviceDataStream> results = null;

		SimpleDateFormat sdfSource = new SimpleDateFormat("yyyy-MM-dd");

		// parse the string into Date object
		Date date = sdfSource.parse(created_date.split("T")[0]);

		// create SimpleDateFormat object with desired date format
		SimpleDateFormat sdfDestination = new SimpleDateFormat("MM/dd/yy");

		// parse the date into another format
		// strDate = sdfDestination.format(date);
		System.out.println(" sdfDestination.format(date) " + sdfDestination.format(date));
		// deviceDataStrem1 = devicedatarepo.findByDevice_id(deviceId);
		System.out.println("Device id " + deviceId);// .andOperator(Criteria.where("Message_Type").is("sensor")
		AggregationOperation match1 = Aggregation.match(Criteria.where("Device_Id").is(deviceId)
				.orOperator((Criteria.where("Message_Type").is("sensor")),
						Criteria.where("Message_Type").is("GPS MESSAGE"))
				.andOperator(Criteria.where("current_terminal_date").gte(sdfDestination.format(date))));

		Aggregation aggregation = Aggregation.newAggregation(match1);
		System.out.println("aggregation " + aggregation);
		results = mongoTemplate.aggregate(aggregation, "DeviceDataStream", DeviceDataStream.class);
	
      //System.out.println("results "+results);

		List<Float> list = new ArrayList<Float>();
		List<Devicedatatemp> devDataList = new ArrayList<Devicedatatemp>();
		System.out.println("devDataList "+devDataList);
		List<String> batteryVal = new ArrayList<>();
		String maxTempThres = shipment.getTemp().split(" ")[2];
		float maxTempThresF = Float.valueOf(shipment.getTemp().split(" ")[2].replace(" c", ""));
		 System.out.println("maxTempThres "+maxTempThresF);
		String minTempThes = shipment.getTemp().split(" ")[0];
		float minTempF = Float.valueOf(shipment.getTemp().split(" ")[0]);
		 System.out.println("minTempThes "+minTempF);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yy");
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yy");
		String tempAddress = "";		
		for (DeviceDataStream dv : results) {
			// System.out.println("dv.getMessage_Type() "+dv.getMessage_Type());
//System.out.println("dv.getCurrent_terminal_date() "+dv.getCurrent_terminal_date());
			System.out.println("dv.getCurrent_terminal_date() "+dv.getCurrent_terminal_date());
			LocalDate date1 = null;

			date1 = LocalDate.parse(dv.getCurrent_terminal_date(), formatter);

			String dateTime = date1.toString() + "T" + dv.getCurrent_terminal_time() + ".000Z";

			if (dv.getMessage_Type().equals("sensor") || dv.getMessage_Type().equals("GPS MESSAGE")) {
				if (dateTime.compareTo(shipment.getCreated_Date()) > 0) {

					Devicedatatemp devData = new Devicedatatemp();
					devData.setSensorTemp(dv.getFirst_Sensor_temperature());
					devData.setUTC(dv.getCurrent_terminal_date() + " " + dv.getCurrent_terminal_time());
					// System.out.println("dv.getDevice_Id() "+dv.getDevice_Id());
					// System.out.println("dv.getReporting_Date() + \"T\" + dv.getReporting_time()
					// "+dv.getReporting_Date() + "T" + dv.getReporting_time() );
					devData.setReportDateTime(dv.getReporting_Date() + "T" + dv.getReporting_time() + "Z");

					devData.setMessage_Type(dv.getMessage_Type());	
//					cal.setMessage_Type(dv.getMessage_Type());
					devData.setLongitude(dv.getLongitude());
					devData.setLatitude(dv.getLatitude());
					devData.setDevice_Id(dv.getDevice_Id());
	//				System.out.println("dv.getAddress() "+dv.getAddress());
					tempAddress = dv.getAddress();
					if (!dv.getAddress().equals("")) {
	//					System.out.println("in not null");
						devData.setAddress(dv.getAddress());
		//				tempAddress = dv.getAddress();
					} else {
	//					System.out.println("in null");
						devData.setAddress(tempAddress);
					}
					batteryVal.add(dv.getBattery_Level());
					devDataList.add(devData);
																															
				}
			}
		}
		Collections.sort(devDataList, Devicedatatemp.uTCComparator);
		String currentDate = null;
//		String pdf2FileName = "c:\\SMAASMailAttachments\\SCMPDF\\Shipment " + shipment.getShipment_Num()
//				+ " All_Data_points.pdf";
		
		cal.setDevDataList(devDataList);
		
		
		List<Devicedatatemp> bat = new ArrayList<>();
		bat.add(devDataList.get(0));
		bat.add(devDataList.get(devDataList.size() - 1));

		String batteryStart = String.valueOf(100 * Float.valueOf(batteryVal.get(0)) - 318);
		String batterEnd = String.valueOf(100 * Float.valueOf(batteryVal.get(batteryVal.size() - 1)) - 318);

		for (Devicedatatemp dv : devDataList) {
			// System.out.println("dv.getMessage_Type() " + dv.getMessage_Type());
			if (dv.getMessage_Type().equals("sensor")) {
				Float s = 0F; //before it is given as dv.getSensorTemp() !=""
	//			if (dv.getSensorTemp() != "" || dv.getSensorTemp() != null || !dv.getSensorTemp().isEmpty()) {
				if (!dv.getSensorTemp().equals("") || !dv.getSensorTemp().equals(null) || !dv.getSensorTemp().isEmpty()) {
					// System.out.println(dv.getSensorTemp());
					s = Float.valueOf(dv.getSensorTemp().replace(" C", ""));
					String nextDate = dv.getUTC();
					if (currentDate == null) {
						currentDate = nextDate;
						continue;
					}
					
					currentDate = nextDate;
					

					list.add(s);

				}

			}
		}

	/**********   for calculating no.of incursion & excursions and time out of Threshold    **********/

	int count = 0;
	int hours = 0;
	int min = 0;
	int sec = 0;
//	String duration = "";
	boolean temp = false;
	String startTime = "";
	String endTime = "";
	String lastUTC = "";
	long finalDuration = 0;
	SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
	int startTimeCount = 0;
	for (Devicedatatemp dv : devDataList) {
		System.out.println(dv);

		if (dv.getMessage_Type().equals("sensor")) {
			Float s = 0F; // before it is given as dv.getSensorTemp() !=""
			// if (dv.getSensorTemp() != "" || dv.getSensorTemp() != null ||
			// !dv.getSensorTemp().isEmpty()) {
			if (!dv.getSensorTemp().equals("") || !dv.getSensorTemp().equals(null) || !dv.getSensorTemp().isEmpty()) {
				// System.out.println(dv.getSensorTemp());
				s = Float.valueOf(dv.getSensorTemp().replace(" C", ""));
				// String nextDate = dv.getUTC();
				System.out.println(dv.getSensorTemp());

				if (s >= maxTempThresF + 0.5 || s <= minTempF - 0.5) {
					temp = true;
					// strattime
					if(startTimeCount == 0)
					startTime = dv.getUTC();	
					startTimeCount = startTimeCount+1;
					lastUTC = dv.getUTC();
					System.out.println("startTime :" +startTime);
					
				} else {

					if (temp) {
//								String endTime = dv.getUTC;
						// endtime
						count++;
						temp = false;
						endTime = dv.getUTC();
						  Date d1 = null;
						    Date d2 = null;
						    try {
						        d1 = format.parse(startTime);
						        d2 = format.parse(endTime);
						    } catch (ParseException e) {
						        e.printStackTrace();
						    }
						    
//						Date startDate = // Set start date
//								Date endDate   = // Set end date

								long duration  = d2.getTime() - d1.getTime();
								System.out.println("duration :" +duration);
								 finalDuration = finalDuration+duration;
						System.out.println("endTime :" +endTime);
					}
				}

				// list2.add(s);
			}
		}
	}
	if (temp) {
		count++;
		temp = false;
		//// last record utc----endtime
		endTime = lastUTC;
		  Date d1 = null;
		    Date d2 = null;
		    try {
		        d1 = format.parse(startTime);
		        d2 = format.parse(endTime);
		    } catch (ParseException e) {
		        e.printStackTrace();
		    }
		    
//		Date startDate = // Set start date
//				Date endDate   = // Set end date

				long duration  = d2.getTime() - d1.getTime();
				System.out.println("duration :" +duration);
				finalDuration = finalDuration+duration;
		System.out.println("endTime :" +endTime);

	}
	System.out.println(count);

//	duration = "h" + hours + "m" + min + "s" + sec;
	 
			long diffInSeconds = TimeUnit.MILLISECONDS.toSeconds(finalDuration);
			System.out.println("diffInSeconds :" +diffInSeconds);
			long diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(finalDuration);
			System.out.println("diffInMinutes :" +diffInMinutes);
			long diffInHours = TimeUnit.MILLISECONDS.toHours(finalDuration);
			System.out.println("diffInHours :" +diffInHours);
			long diffInDays = TimeUnit.MILLISECONDS.toDays(finalDuration);
		System.out.println("diffInDays :" +diffInDays);

	cal.setNumber_of_Excursion_and_Incursion(String.valueOf(count));
	cal.setTime_out_of_threshold(String.valueOf(diffInHours) + " h");

	System.out.println("i am here");

//		cal.setTime_out_of_threshold(total_time);
/////////////////////////////////////////////////////////////////////////////////		
		
		/*
		 * String tabEnd = "</font>\r\n"+"</table>\r\n" +
		 * "    <br><br><br>        			    \r\n" + "         \r\n" +
		 * "   			      \r\n" + "            			    \r\n" +
		 * "            			    </body>  \r\n" + "\r\n" + "\r\n"; alaramZone =
		 * alaramZone + tabEnd;
		 */

		// System.out.println("Max " + Collections.max(list));
		// System.out.println("Min " + Collections.min(list));
		DoubleSummaryStatistics summaryStats = list.stream().mapToDouble((a) -> a).summaryStatistics();
		// System.out.println("Average of a List = " + summaryStats.getAverage());
		
	
		// System.out.println("list "+list);
		float maxTemp = Collections.max(list);
		float minTemp = Collections.min(list);
//		cal.setHighestTemp(maxTemp);
		cal.setHighestTemp(String.valueOf(Float.valueOf(maxTemp)) + " C");		
		cal.setLowestTemp(String.valueOf(Float.valueOf(minTemp)) + " C");
		
		double avgTemp = Math.round(summaryStats.getAverage() * Math.pow(10, 2)) / Math.pow(10, 2);

//		cal.setAvgTemp(avgTemp);
		cal.setAvgTemp(String.valueOf(Double.valueOf(avgTemp)) + " C");
		

		Date shipCreatedDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse(created_date);
		Date shipEndDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse(endDate);
		System.out.println(shipCreatedDate+" checking dates"+shipEndDate);
		String elapsedTime = findDifference(shipCreatedDate, shipEndDate);
		Double mktValue = mktCalculator(avgTemp);
		mktValue = Math.round(mktValue * Math.pow(10, 4)) / Math.pow(10, 4);
		
	
//		cal.setMktValue(mktValue);
		cal.setMktValue(String.valueOf(Double.valueOf(mktValue)) + " C");
		
		cal.setStartTime(shipCreatedDate.toString());
		cal.setEndTime(shipEndDate.toString());
		cal.setElapsedTime(elapsedTime);
		cal.setDataPoints(String.valueOf(list.size()));
		cal.setBatterystart(batteryStart+" %");
		cal.setBatteryend(batterEnd+" %");
		cal.setTemperature_Max(maxTempThres + " c");
		cal.setTemperature_Min(minTempThes + " c");
				
		cal.setDelivery_Number(shipment.getInvoice_Number());
		cal.setCmo_Ref_Number(shipment.getCmo_Ref_Number());
		cal.setContainer_Number(shipment.getShipper_Number());
	//	cal.setRoute_Id(shipment.getRoute_Id());
	//	cal.setGoods_Id(shipment.getGoods_Id());
		cal.setRoute_Id(shipment.getCustRouteId());
      	cal.setGoods_Id(shipment.getCustGoodId());
		cal.setGoods_Type(shipment.getGoods_Desc());
		
		String dateString = shipment.getEstimated_Delivery_Date();
	    SimpleDateFormat sdf_expected = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	    Date date_expected = sdf_expected.parse(dateString);
	    sdf_expected = new SimpleDateFormat("yyyy-MM-dd");
	    dateString = sdf_expected.format(date_expected);
	    
		cal.setExpected_Delivery_Date(dateString);
		
		cal.setPo_Number(shipment.getPo_Number());
		cal.setNdc_Number(shipment.getNdc_Number());
		cal.setBatch_Id(shipment.getBatch_Id());
		cal.setSerial_Number_of_goods(shipment.getSerial_Number_of_goods());
		cal.setShipment_Id(shipment.getShipment_Id());
			
		String dateStr = shipment.getCreated_Date();
	    SimpleDateFormat sdf_created = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	    Date date_created = sdf_created.parse(dateStr);
	    sdf_created = new SimpleDateFormat("yyyy-MM-dd");
	    dateStr = sdf_created.format(date_created);
		
		cal.setDate(dateStr);
		
		
		System.out.println(shipment);
		Query query = new Query(Criteria.where("Shipment_Id").is(Shipment_Id));
		System.out.println(query);

		return cal;
	}
	static String findDifference(Date d1, Date d2) {
		String elapsedTime = "";
//System.out.print("Date 1 "+d1+":::::Date 2"+d2);
		try {

			long difference_In_Time = d2.getTime() - d1.getTime();

			long difference_In_Seconds = (difference_In_Time / 1000) % 60;

			long difference_In_Minutes = (difference_In_Time / (1000 * 60)) % 60;

			long difference_In_Hours = (difference_In_Time / (1000 * 60 * 60)) % 24;

			long difference_In_Days = (difference_In_Time / (1000 * 60 * 60 * 24)) % 365;

			elapsedTime = difference_In_Days + " d, " + difference_In_Hours + " h, " + difference_In_Minutes + " m, "
					+ difference_In_Seconds + " s";
			 System.out.println("Difference " + "between two dates is: "+difference_In_Time);
		}

		// Catch the Exception
		catch (Exception e) {
			e.printStackTrace();
		}
		return elapsedTime;
	}

	static Double mktCalculator(double avgTemp) {

		double avg = avgTemp;

		double kelvinTemp = 0;

		double coef1 = 0;

		double coef2 = 0;
		double clog = 0, TK = 0, MKT = 0;

		kelvinTemp = avg + 273;

		coef1 = -10000 / kelvinTemp;

		coef2 = Math.exp(coef1);

		clog = (Math.log(coef2)) * -1;

		TK = 10000 / clog;

		MKT = TK - 273;
		return MKT;
	}	
	
	
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getCanCompleteShipment/{Shipment_Id}/{Login_Bp}")
	public CanCompleteShipmentDto CanCompleteShipment(@PathVariable(value = "Shipment_Id") String Shipment_Id,
			@PathVariable(value = "Login_Bp") String Login_Bp) {
		CanCompleteShipmentDto dto = new CanCompleteShipmentDto();
		List<ShipmentTransactions> sp = new ArrayList<>();
		Criteria crt = new Criteria();
		crt.andOperator(Criteria.where("Shipment_Id").is(Shipment_Id));
		Query query = new Query(crt);
		sp = mongoTemplate.find(query, ShipmentTransactions.class);
		for (ShipmentTransactions tr : sp) {
			if (tr.getEvent_Name().equals("Final Receipt") && tr.getPartner_From().equals(Login_Bp)) {
				dto.setCanComplete(true);
			}
		}
		System.out.println(dto.isCanComplete());
		if ("false".equals(dto.isCanComplete())) {
			dto.setCanComplete(false);
		}
		return dto;
	}

	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getAllTxns/{Shipment_Id}") public List<ShipmentTransactions>
	 * getAllEventTxnsShipmentId(
	 * 
	 * @PathVariable(value = "Shipment_Id") String Shipment_Id) {
	 * 
	 * List<ShipmentTransactions> sp = new ArrayList<>(); Criteria crt = new
	 * Criteria(); crt.andOperator(Criteria.where("Shipment_Id").is(Shipment_Id));
	 * Query query = new Query(crt); sp = mongoTemplate.find(query,
	 * ShipmentTransactions.class); return sp; }
	 */
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getAllTxns/{Shipment_Id}")
	public List<ShipmentTransactions> getAllEventTxnsShipmentId(
			@PathVariable(value = "Shipment_Id") String Shipment_Id) {

		List<ShipmentTransactions> sp = new ArrayList<>();
		Criteria crt = new Criteria();
		crt.andOperator(Criteria.where("Shipment_Id").is(Shipment_Id));
		Query query = new Query(crt);
		sp = mongoTemplate.find(query, ShipmentTransactions.class);
		List<BusinessPartner> ev = new ArrayList<>();
		for (ShipmentTransactions txn : sp) {
			Criteria crt1 = new Criteria();
			crt1.andOperator(Criteria.where("BP_Id").is(txn.getPartner_From()));
			Query query1 = new Query(crt1);
			ev = mongoTemplate.find(query1, BusinessPartner.class);
			for (BusinessPartner bp : ev) {
				for (Events e : bp.getEvents()) {
					for (ShipmentTransactions tr : sp) {
						if (e.getEvent_Status().equals(tr.getEvent_Name())) {
							tr.setEvent_Id(tr.getEvent_Id());
						}
					}
				}
			}
		}

		return sp;
	}

	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getAllEventTxns/{Shipment_Id}/{Partner_From}") public
	 * List<ShipmentTransactions> getAllTxnsBasedOnShipmentId(
	 * 
	 * @PathVariable(value = "Shipment_Id") String Shipment_Id,
	 * 
	 * @PathVariable(value = "Partner_From") String Partner_From) {
	 * 
	 * List<ShipmentTransactions> sp = new ArrayList<>(); Criteria crt = new
	 * Criteria(); crt.andOperator(Criteria.where("Shipment_Id").is(Shipment_Id),
	 * Criteria.where("Partner_From").is(Partner_From)); Query query = new
	 * Query(crt); sp = mongoTemplate.find(query, ShipmentTransactions.class);
	 * 
	 * List<BusinessPartner> ev = new ArrayList<>(); Criteria crt1 = new Criteria();
	 * crt1.andOperator(Criteria.where("BP_Id").is(Partner_From)); Query query1 =
	 * new Query(crt1); ev = mongoTemplate.find(query1, BusinessPartner.class); for
	 * (BusinessPartner bp : ev) { for (Events e : bp.getEvents()) { for
	 * (ShipmentTransactions tr : sp) { if
	 * (e.getEvent_Status().equals(tr.getEvent_Name())) {
	 * tr.setEvent_Id(e.getEvent_Id()); } } } } return sp; }
	 */
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/deleteEventShip")
	public boolean deleteNewEvent(@Validated @RequestBody  UpdateEvent event) {
		boolean flag = false;
		List<ShipmentTransactions> list = shiptransrepo.findByPartner_from(event.getPartnerFrom());
		try {
			for (ShipmentTransactions list1 : list) {
				if (list1.getShipment_Id().equals(event.getShipment_Number())) {
					if (list1.getPartner_From().equals(event.getPartnerFrom())) {
						if (list1.getEvent_Name().equals(event.getEventType())) {
							Query query = new Query();
							query.addCriteria(new Criteria().andOperator(
									Criteria.where("Shipment_Id").is(event.getShipment_Number()),
									Criteria.where("Partner_From").is(event.getPartnerFrom()),
									Criteria.where("Event_Name").is(event.getEventType())));
							Update update = new Update();
							update.set("Event_Status", "EVENT DELETED");
							mongoTemplate.updateMulti(query, update, "ShipmentTransactions");
							System.out.println("Deleted Event with EventSNo : " + list1.getEvent_SNo());
							return flag = true;
						}

					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return flag;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getShipfromandto/{Customer_Id}")
	public Set<String> getfromto(@PathVariable(value = "Customer_Id") String Customer_Id) {

		List<Shipments> shipment = shiprepo.findByCustomer_id(Customer_Id);

		List<String> shipfromto = new ArrayList<>();

		for (Shipments shp : shipment) {

			shipfromto.add(shp.getRoute_From());
			shipfromto.add(shp.getRoute_To());

		}

		Set<String> devicelist = new LinkedHashSet<String>(shipfromto);
		return devicelist;

	}

	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/updateEventShip") public boolean
	 * updateNewShipment(@RequestBody UpdateEvent event) { boolean flag = false;
	 * ShipmentTransactions trans = new ShipmentTransactions();
	 * List<ShipmentTransactions> list =
	 * shiptransrepo.findByPartner_from(event.getPartnerFrom()); try { for
	 * (ShipmentTransactions list1 : list) { if
	 * (list1.getShipment_Id().equals(event.getShipment_Number())) { if
	 * (list1.getPartner_From().equals(event.getPartnerFrom())) { if
	 * (list1.getEvent_Name().equals(event.getEventType())) { Query query = new
	 * Query(); query.addCriteria(new Criteria().andOperator(
	 * Criteria.where("Shipment_Id").is(event.getShipment_Number()),
	 * Criteria.where("Partner_From").is(event.getPartnerFrom()),
	 * Criteria.where("Event_Name").is(event.getEventType()))); Update update = new
	 * Update();
	 * 
	 * // update.set("Event_Name", event.getEventType()); Date date = new Date();
	 * SimpleDateFormat formatter = new
	 * SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); String updateDate =
	 * formatter.format(date); update.set("EventReferenceNumber",
	 * event.getEventReferenceNumber()); update.set("Event_Status", "Completed");
	 * update.set("TypeOfReference", event.getTypeOfReference());
	 * update.set("Event_Exec_Date", updateDate); mongoTemplate.updateMulti(query,
	 * update, "ShipmentTransactions");
	 * System.out.println("Updated Event with EventSNo : " + list1.getEvent_SNo());
	 * return flag = true;
	 * 
	 * }
	 * 
	 * } } }
	 * 
	 * } catch (Exception e) { // TODO: handle exception }
	 * 
	 * return flag;
	 * 
	 * }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/updateEventShip") public Response
	 * updateNewShipment(@RequestBody UpdateEvent event) {
	 * 
	 * Response resp = new Response();
	 * 
	 * // resp.setStatus(false); ShipmentTransactions trans = new
	 * ShipmentTransactions(); List<ShipmentTransactions> list =
	 * shiptransrepo.findByPartner_from(event.getPartnerFrom()); Shipments shipment
	 * = new Shipments(); List<Shipments> shipmentlist = shiprepo.findAll();
	 * 
	 * try { for (ShipmentTransactions list1 : list) { if
	 * (list1.getShipment_Id().equals(event.getShipment_Number())) { if
	 * (list1.getPartner_From().equals(event.getPartnerFrom())) { if
	 * (list1.getEvent_Name().equals(event.getEventType())) { Query query = new
	 * Query(); query.addCriteria(new Criteria().andOperator(
	 * Criteria.where("Shipment_Id").is(event.getShipment_Number()),
	 * Criteria.where("Partner_From").is(event.getPartnerFrom()),
	 * Criteria.where("Event_Name").is(event.getEventType()))); Update update = new
	 * Update(); // update.set("Event_Name", event.getEventType());
	 * update.set("EventReferenceNumber", event.getEventReferenceNumber());
	 * update.set("Event_Status", "Completed"); update.set("TypeOfReference",
	 * event.getTypeOfReference()); update.set("EvidenceList",
	 * event.getEvidencelist());
	 * 
	 * mongoTemplate.updateMulti(query, update, "ShipmentTransactions");
	 * 
	 * 
	 * 
	 * resp.setStatus(true); resp.setMessasge("Event Updated Successfully"); return
	 * resp;
	 * 
	 * } // Query query1 = new Query(); // Update update1 = new Update(); //
	 * query1.addCriteria(Criteria.where("Shipment_Id").is(event.getShipment_Number(
	 * ))); // update1.set("Shipment_Status", list1.getEvent_Name()); //
	 * mongoTemplate.(query1, update1, "Shipments");
	 * 
	 * System.out.println("Updated Event with EventSNo : " + list1.getEvent_SNo());
	 * 
	 * } } }
	 * 
	 * } catch (Exception e) { resp.setMessasge("Event Failed to update");
	 * System.out.println("catch"); // TODO: handle exception }
	 * 
	 * return resp; }
	 */

	/*
	 * @ResponseBody
	 * 
	 * @PostMapping("/updateEventShip") public Response
	 * updateNewShipment(@RequestBody UpdateEvent event) {
	 * 
	 * Response resp= new Response();
	 * 
	 * //resp.setStatus(false); ShipmentTransactions trans = new
	 * ShipmentTransactions(); List<ShipmentTransactions> list =
	 * shiptransrepo.findByPartner_from(event.getPartnerFrom()); Shipments shipment
	 * = new Shipments(); List<Shipments> shipmentlist =shiprepo.findAll();
	 * 
	 * try { for (ShipmentTransactions list1 : list) { if
	 * (list1.getShipment_Id().equals(event.getShipment_Number())) { if
	 * (list1.getPartner_From().equals(event.getPartnerFrom())) { if
	 * (list1.getEvent_Name().equals(event.getEventType())) { Query query = new
	 * Query(); query.addCriteria(new Criteria().andOperator(
	 * Criteria.where("Shipment_Id").is(event.getShipment_Number()),
	 * Criteria.where("Partner_From").is(event.getPartnerFrom()),
	 * Criteria.where("Event_Name").is(event.getEventType()))); Update update = new
	 * Update(); // update.set("Event_Name", event.getEventType());
	 * update.set("EventReferenceNumber", event.getEventReferenceNumber());
	 * update.set("Event_Status", "Completed"); update.set("TypeOfReference",
	 * event.getTypeOfReference());
	 * update.set("Event_Exec_Date",event.getEvent_Exec_Date());
	 * 
	 * mongoTemplate.updateMulti(query, update, "ShipmentTransactions");
	 * 
	 * Query query1 = new Query(); Update update1 = new Update();
	 * query1.addCriteria(Criteria.where("Shipment_Id").is(event.getShipment_Number(
	 * ))); update1.set("Shipment_Status", list1.getEvent_Name());
	 * mongoTemplate.updateFirst(query1, update1, "Shipments");
	 * 
	 * 
	 * System.out.println("Updated Event with EventSNo : " + list1.getEvent_SNo());
	 * 
	 * resp.setStatus(true); resp.setMessasge("Event Updated Successfully"); return
	 * resp;
	 * 
	 * }
	 * 
	 * } } }
	 * 
	 * } catch (Exception e) { resp.setMessasge("Event Failed to update");
	 * System.out.println("catch"); // TODO: handle exception }
	 * 
	 * return resp; }
	 */
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/updateEventShip")
	public Response updateNewShipment(@Validated @RequestBody UpdateEvent event) {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String strDate = formatter.format(date);
		Response resp = new Response();

		// resp.setStatus(false);
		ShipmentTransactions trans = new ShipmentTransactions();
		List<ShipmentTransactions> list = shiptransrepo.findByShipment_Id(event.getShipment_Number());
		Shipments shipment = new Shipments();
		List<Shipments> shipmentlist = shiprepo.findAll();

		try {
			for (ShipmentTransactions list1 : list) {
				if (list1.getEvent_Name().equals(event.getEventType())) {
					if (list1.getPartner().equals(event.getPartner())) {

						System.out.println("asdads" + event.getShipment_Number());
						System.out.println("asdads" + event.getPartnerFrom());
						System.out.println("asdads" + event.getEventType());
						
		//////// commented code till return resp is the code before updating the device_id for updateEventShip api or page ////////				
//						Query query = new Query();
//
//						query.addCriteria(
//								new Criteria().andOperator(Criteria.where("Shipment_Id").is(event.getShipment_Number()),
//										Criteria.where("Partner").is(event.getPartner()),
//										Criteria.where("Event_Name").is(event.getEventType())));
//						                Criteria.where("Device_Id").is(event.getDevice_Id());
//						
//						Update update = new Update();
//						update.set("Event_Name", event.getEventType());
//						update.set("EventReferenceNumber", event.getEventReferenceNumber());
//						update.set("Event_Status", "Completed");
//						update.set("TypeOfReference", event.getTypeOfReference());
//						update.set("Event_Exec_Date", strDate);
//						update.set("Evidence", event.getEvidence());
//						update.set("EvidenceList", event.getEvidencelist());
//						update.set("Device_Id", event.getDevice_Id());
//
//						mongoTemplate.updateMulti(query, update, "ShipmentTransactions");
//
//						long eventslno = Long.valueOf((list1.getEvent_SNo() + 1));
//						System.out.println("Long valueeeee::::" + eventslno);
//						ShipmentTransactions eventsno = shiptransrepo.findByEvent_Sno(eventslno);
//						String reqval = eventsno.getEvent_Name();
//						System.out.println("Reqval::::" + reqval);
//						System.out.println("Eventss updating to initailization" + eventsno);
//						System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
//								+ eventsno.getEvent_SNo());
//						Query query2 = new Query();
//						Update update2 = new Update();
//
//						query2.addCriteria(
//								new Criteria().andOperator(Criteria.where("Shipment_Id").is(eventsno.getShipment_Id()),
//										Criteria.where("Event_SNo").is(eventsno.getEvent_SNo())));
//
//						System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
//								+ eventsno.getEvent_SNo());
//
//						update2.set("Event_Status", "Initialized");
//						mongoTemplate.updateMulti(query2, update2, "ShipmentTransactions");
//
//						Query query1 = new Query();
//						Update update1 = new Update();
//						query1.addCriteria(Criteria.where("Shipment_Id").is(event.getShipment_Number()));
//						update1.set("Shipment_Status", reqval);
//						mongoTemplate.updateFirst(query1, update1, "Shipments");
//						resp.setMessage("Event Updated Successfully");
//						resp.setStatus(true);
//
//						// generateemail(event.getShipment_Number());
//						return resp;
//
//					}
//
//				}
					
		if (list1.getEvent_Name().equals("Attach Device")) {
			for (ShipmentTransactions list2 : list) {
				if (!list2.getEvent_Name().equals("Attach Device")) {
					Query query = new Query();
					query.addCriteria(
							new Criteria().andOperator(Criteria.where("Shipment_Id").is(event.getShipment_Number()),
									Criteria.where("Partner").is(event.getPartner())));
					// Criteria.where("Device_Id").is(event.getDevice_Id());

					Update update = new Update();
			//		update.set("Device_Id", event.getDevice_Id());
					if(list1.getDevice_Id().equals("") || list1.getDevice_Id().equals(null)) {
					    update.set("Device_Id", event.getDevice_Id());
						}
					else {
							update.set("Device_Id", list1.getDevice_Id());
						}
					mongoTemplate.updateMulti(query, update, "ShipmentTransactions");

				}

				Query querydev = new Query();

				querydev.addCriteria(
						new Criteria().andOperator(Criteria.where("Shipment_Id").is(event.getShipment_Number())

						));
				Update updatedev = new Update();
		//		updatedev.set("Device_Id", event.getDevice_Id());
				if(list1.getDevice_Id().equals("") || list1.getDevice_Id().equals(null)) {
            		updatedev.set("Device_Id", event.getDevice_Id());
					}else {
						updatedev.set("Device_Id", list1.getDevice_Id());
					}
				mongoTemplate.updateFirst(querydev, updatedev, "Shipments");

				Query query = new Query();
				query.addCriteria(new Criteria().andOperator(Criteria.where("Device_Id").is(event.getDevice_Id())));
				Update update = new Update();
				update.set("DeviceStatusReferred", "Attached To Shipment");
				mongoTemplate.updateMulti(query, update, "Devices");

			}
			Query query = new Query();

			query.addCriteria(new Criteria().andOperator(Criteria.where("Shipment_Id").is(event.getShipment_Number()),
					Criteria.where("Partner").is(event.getPartner()),
					Criteria.where("Event_Name").is(event.getEventType())));
			// Criteria.where("Device_Id").is(event.getDevice_Id());

			Update update = new Update();
			update.set("Event_Name", event.getEventType());
			update.set("EventReferenceNumber", event.getEventReferenceNumber());
			update.set("Event_Status", "Completed");
			update.set("TypeOfReference", event.getTypeOfReference());
			update.set("Event_Exec_Date", strDate);
			update.set("Evidence", event.getEvidence());
			update.set("EvidenceList", event.getEvidencelist());
			if (list1.getDevice_Id().equals("") || list1.getDevice_Id().equals(null)) {
				update.set("Device_Id", event.getDevice_Id());
			}

			mongoTemplate.updateMulti(query, update, "ShipmentTransactions");

			long eventslno = Long.valueOf((list1.getEvent_SNo() + 1));
			System.out.println("Long valueeeee::::" + eventslno);
			ShipmentTransactions eventsno = shiptransrepo.findByEvent_Sno(eventslno);
			String reqval = eventsno.getEvent_Name();
			System.out.println("Reqval::::" + reqval);
			System.out.println("Eventss updating to initailization" + eventsno);
			System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
					+ eventsno.getEvent_SNo());
			Query query2 = new Query();
			Update update2 = new Update();

			query2.addCriteria(new Criteria().andOperator(Criteria.where("Shipment_Id").is(eventsno.getShipment_Id()),
					Criteria.where("Event_SNo").is(eventsno.getEvent_SNo())));

			System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
					+ eventsno.getEvent_SNo());

			update2.set("Event_Status", "Initialized");
			mongoTemplate.updateMulti(query2, update2, "ShipmentTransactions");

			Query query1 = new Query();
			Update update1 = new Update();
			query1.addCriteria(Criteria.where("Shipment_Id").is(event.getShipment_Number()));
			update1.set("Shipment_Status", reqval);
			mongoTemplate.updateFirst(query1, update1, "Shipments");
			resp.setMessage("Event Updated Successfully");
			resp.setStatus(true);

			// generateemail(event.getShipment_Number());
			return resp;
		} else {

			Query query = new Query();

			query.addCriteria(new Criteria().andOperator(Criteria.where("Shipment_Id").is(event.getShipment_Number()),
					Criteria.where("Partner").is(event.getPartner()),
					Criteria.where("Event_Name").is(event.getEventType())));

			Update update = new Update();
			update.set("Event_Name", event.getEventType());
			update.set("EventReferenceNumber", event.getEventReferenceNumber());
			update.set("Event_Status", "Completed");
			update.set("TypeOfReference", event.getTypeOfReference());
			update.set("Event_Exec_Date", strDate);
			update.set("Evidence", event.getEvidence());
			update.set("EvidenceList", event.getEvidencelist());

			mongoTemplate.updateMulti(query, update, "ShipmentTransactions");

			long eventslno = Long.valueOf((list1.getEvent_SNo() + 1));
			System.out.println("Long valueeeee::::" + eventslno);
			ShipmentTransactions eventsno = shiptransrepo.findByEvent_Sno(eventslno);
			String reqval = eventsno.getEvent_Name();
			System.out.println("Reqval::::" + reqval);
			System.out.println("Eventss updating to initailization" + eventsno);
			System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
					+ eventsno.getEvent_SNo());
			Query query2 = new Query();
			Update update2 = new Update();

			query2.addCriteria(new Criteria().andOperator(Criteria.where("Shipment_Id").is(eventsno.getShipment_Id()),
					Criteria.where("Event_SNo").is(eventsno.getEvent_SNo())));

			System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
					+ eventsno.getEvent_SNo());

			update2.set("Event_Status", "Initialized");
			mongoTemplate.updateMulti(query2, update2, "ShipmentTransactions");

			Query query1 = new Query();
			Update update1 = new Update();
			query1.addCriteria(Criteria.where("Shipment_Id").is(event.getShipment_Number()));
			update1.set("Shipment_Status", reqval);
			mongoTemplate.updateFirst(query1, update1, "Shipments");
			resp.setMessage("Event Updated Successfully");
			resp.setStatus(true);

			// generateemail(event.getShipment_Number());
			return resp;
		}

	}

}
						
				else {

					System.out.println("event_statussssss::::" + list1.getEvent_Status());

					if (!list1.getEvent_Status().equals("Completed")) {

						System.out.println("i am coming to complete the event");

						Query query4 = new Query();

						query4.addCriteria(
								new Criteria().andOperator(Criteria.where("Shipment_Id").is(list1.getShipment_Id()),
										Criteria.where("Partner").is(list1.getPartner()),
										Criteria.where("Event_Name").is(list1.getEvent_Name())));
						       //         Criteria.where("Device_Id").is(event.getDevice_Id());						 
						Update update3 = new Update();
						update3.set("Event_Name", list1.getEvent_Name());
						update3.set("EventReferenceNumber", event.getEventReferenceNumber());
						update3.set("Event_Status", "Completed");
						update3.set("TypeOfReference", event.getTypeOfReference());
						update3.set("Event_Exec_Date", strDate);
						update3.set("Evidence", event.getEvidence());
		//				update3.set("Device_Id", event.getDevice_Id());
						mongoTemplate.updateMulti(query4, update3, "ShipmentTransactions");
						System.out.println("update mongo collection also");
					}

				}

			}

		} catch (Exception e) {
			resp.setMessage("Event Failed to update");
			System.out.println("catch");
			// TODO: handle exception
		}

		return resp;
	}

//	@ResponseBody
//	@PostMapping("/updateEventShip")
//	public Response updateNewShipment(@RequestBody UpdateEvent event) {
//
//	Response resp = new Response();
//
//	// resp.setStatus(false);
//	ShipmentTransactions trans = new ShipmentTransactions();
//	List<ShipmentTransactions> list = shiptransrepo.findByShipment_Id(event.getShipment_Number());
//	Shipments shipment = new Shipments();
//	List<Shipments> shipmentlist = shiprepo.findAll();
//
//	try {
//	for (ShipmentTransactions list1 : list) {
//
//	if (list1.getEvent_Name().equals(event.getEventType())) {
//	if (list1.getPartner().equals(event.getPartner())) {
//
//	Query query = new Query();
//	System.out.println("before query");
//	query.addCriteria(
//	new Criteria().andOperator(Criteria.where("Shipment_Id").is(event.getShipment_Number()),
//	Criteria.where("Partner").is(event.getPartner()),
//	Criteria.where("Event_Name").is(event.getEventType())));
//
//	Update update = new Update();
//	update.set("Event_Name", event.getEventType());
//	update.set("EventReferenceNumber", event.getEventReferenceNumber());
//	update.set("Event_Status", "Completed");
//	update.set("TypeOfReference", event.getTypeOfReference());
//	mongoTemplate.updateMulti(query, update, "ShipmentTransactions");
//	System.out.println("after query");
//	long eventslno = Long.valueOf((list1.getEvent_SNo() + 1));
//	System.out.println("Long valueeeee::::" + eventslno);
//	ShipmentTransactions eventsno = shiptransrepo.findByEvent_Sno(eventslno,event.getShipment_Number());
//	String reqval = eventsno.getEvent_Name();
//	System.out.println("Reqval::::" + reqval);
//	System.out.println("Eventss updating to initailization" + eventsno);
//	System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
//	+ eventsno.getEvent_SNo());
//	Query query2 = new Query();
//	Update update2 = new Update();
//
//	query2.addCriteria(
//	new Criteria().andOperator(Criteria.where("Shipment_Id").is(eventsno.getShipment_Id()),
//	Criteria.where("Event_SNo").is(eventsno.getEvent_SNo())));
//
//	System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
//	+ eventsno.getEvent_SNo());
//
//	update2.set("Event_Status", "Initialized");
//	mongoTemplate.updateMulti(query2, update2, "ShipmentTransactions");
//
//	Query query1 = new Query();
//	Update update1 = new Update();
//	query1.addCriteria(Criteria.where("Shipment_Id").is(event.getShipment_Number()));
//	update1.set("Shipment_Status", reqval);
//	// update1.set("Partner", eventsno.get)
//	mongoTemplate.updateFirst(query1, update1, "Shipments");
//
//	resp.setStatus(true);
//	resp.setMessage("Event Updated Successfully");
//	return resp;
//
//	}
//
//	} else {
//
//	System.out.println("event_statussssss::::" + list1.getEvent_Status());
//
//	if (!list1.getEvent_Status().equals("Completed")) {
//
//	System.out.println("i am coming to complete the event");
//
//	Query query4 = new Query();
//
//	query4.addCriteria(
//	new Criteria().andOperator(Criteria.where("Shipment_Id").is(list1.getShipment_Id()),
//	Criteria.where("Partner").is(list1.getPartner()),
//	Criteria.where("Event_Name").is(list1.getEvent_Name())));
//	Update update3 = new Update();
//	update3.set("Event_Name", list1.getEvent_Name());
//	update3.set("EventReferenceNumber", event.getEventReferenceNumber());
//	update3.set("Event_Status", "Completed");
//	update3.set("TypeOfReference", event.getTypeOfReference());
//	mongoTemplate.updateMulti(query4, update3, "ShipmentTransactions");
//	System.out.println("update mongo collection also");
//	}
//
//	}
//	}
//
//	} catch (Exception e) {
//	resp.setMessage("Event Failed to update");
//	System.out.println("catch");
//	// TODO: handle exception
//	}
//
//	return resp;
//	}

	public void generateemail(String shipmentId) {
		List<AlertProfile> alertproifle = alertprofilerepo.findAll();
		System.out.println("in for loop" + alertproifle);
		System.out.println("in alert profile");

		for (AlertProfile alerts : alertproifle) {
			// System.out.println("in forlopp" + alerts.getRoute_Id());

			if (alerts.getAlert_Type().equals("Event")) {
				try {
					// System.out.println("alerts.getAlert_Id() "+alerts.getAlert_Id());
					event(alerts.getRoute_Id(), alerts.getEvent_Name(),

							alerts.getGoods_Type(), alerts.getCustomer_Id(), alerts.getAlert_Id(), shipmentId);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

	}

	public void event(String routeId, String eventName, String goodsType, String customerId, String alertId,
			String shipmentId) throws InterruptedException {

		List<Shipments> shipmentlists = shiprepo.getShipmentsList(shipmentId);

		List<ShipmentTransactions> shipmenttransactionslist = null;

		for (Shipments shipment : shipmentlists) {
			if (shipment.getRoute_Id().equals(routeId) && shipment.getCustomer_Id().equals(customerId)) {

				if (shipment.getGoods_Desc().equals(goodsType)) {
					String deviceid = shipment.getDevice_Id();
					String Shipment_Id = shipment.getShipment_Id();

					shipmenttransactionslist =

							shiptransrepo.findByShipment_Id(Shipment_Id);

					for (ShipmentTransactions transactions : shipmenttransactionslist) {

						if (transactions.getEvent_Name().equals(eventName)
								&& transactions.getDevice_Id().equals(deviceid)) {
							if (transactions.getEvent_Status().equals("Initialized")) {

								System.out.println("Shipment Initialized email");
								List<AlertMaster> altm = alertmasterrepo.findByCustomer_Id(customerId);
								System.out.println("altm:::::" + altm);
								for (AlertMaster alerts : altm) {
									if (alerts.getAlert_Id().equals(alertId)) {
										String[] emails = alerts.getEmail_Addresses();
										System.out.println("emails for initialized " + emails[0]);
										mailsend.sendSimpleMail(alerts.getEmail_Addresses(), alerts.getEmail_Subject(),
												transactions.getEvent_Name() + " event for Shipment Id:" + Shipment_Id
														+ " has been Initialized.");
									}
								}
							}

							else if (transactions.getEvent_Status().equals("Completed")) {
								System.out.println("Shipment Completed email");
								List<AlertMaster> altm = alertmasterrepo.findByCustomer_Id(customerId);
								System.out.println("altm:::::" + altm);
								for (AlertMaster alerts : altm) {
									if (alerts.getAlert_Id().equals(alertId)) {
										String[] emails = alerts.getEmail_Addresses();
										System.out.println("emails for completed " + emails[0]);
										mailsend.sendSimpleMail(alerts.getEmail_Addresses(), alerts.getEmail_Subject(),
												transactions.getEvent_Name() + " event for Shipment Id:" + Shipment_Id
														+ " has been completed.");
									}
								}

							}

						}

					}
				}
			}
		}
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getInternalShipmentId/{BP_Id}")
	public String generateInternalShipmentId(@PathVariable(value = "BP_Id") String BP_Id) throws Exception {
		String sid = null;
		String afterSplit = null;
		String addZeros = null;
		List<String> shipIds = new ArrayList<>();
		List<Shipments> shiplist = shiprepo.findByBP_Id(BP_Id);

		// List<Shipments> ships = shiprepo.findAll();
		System.out.println("xkjcgh" + shiplist);
		if (shiplist == null || shiplist.isEmpty()) {

			Collections.reverse(shipIds);
			String lastId = "T00000000";
//	String lastId = shipIds.get(0);
			String[] splitLastId = lastId.split("T");
			for (String s : splitLastId) {
				afterSplit = s;
			}
			Integer splitInt = Integer.parseInt(afterSplit);
			Integer increment = splitInt + 1;
			String incrementString = increment.toString();
			System.out.println(incrementString);
			if (incrementString.length() == 1) {
				addZeros = "0000000";
			} else if (incrementString.length() == 2) {
				addZeros = "0000000";
			} else if (incrementString.length() == 3) {
				addZeros = "000000";
			} else if (incrementString.length() == 4) {
				addZeros = "00000";
			} else if (incrementString.length() == 5) {
				addZeros = "0000";
			} else if (incrementString.length() == 6) {
				addZeros = "000";
			} else if (incrementString.length() == 6) {
				addZeros = "00";
			} else if (incrementString.length() == 7) {
				addZeros = "0";
			} else if (incrementString.length() == 8) {
				throw new Exception("Its beyong the Limit of the Present One");
			}
			String finalString = "T";
			finalString = finalString.concat(addZeros).concat(incrementString);
			System.out.println(finalString);
			return finalString;
		} else {

			for (Shipments sh : shiplist) {
				sid = sh.getShipment_Id();
				shipIds.add(sid);
			}
			Collections.reverse(shipIds);
			String lastId = shipIds.get(0);
			String[] splitLastId = lastId.split("T");
			for (String s : splitLastId) {
				afterSplit = s;
			}
			Integer splitInt = Integer.parseInt(afterSplit);
			Integer increment = splitInt + 1;
			String incrementString = increment.toString();
			System.out.println(incrementString);
			if (incrementString.length() == 1) {
				addZeros = "0000000";
			} else if (incrementString.length() == 2) {
				addZeros = "000000";
			} else if (incrementString.length() == 3) {
				addZeros = "00000";
			} else if (incrementString.length() == 4) {
				addZeros = "0000";
			} else if (incrementString.length() == 5) {
				addZeros = "000";
			} else if (incrementString.length() == 6) {
				addZeros = "00";
			} else if (incrementString.length() == 7) {
				addZeros = "0";
			} else if (incrementString.length() == 8) {
				throw new Exception("Its beyong the Limit of the Present One");
			}
			String finalString = "T";
			finalString = finalString.concat(addZeros).concat(incrementString);

			// finalString = addZeros.concat(incrementString);
			System.out.println(finalString);

			return finalString;
		}
	}

	public String generateInternalShipmentId() throws Exception {
		String sid = null;
		String afterSplit = null;
		String addZeros = null;
		List<String> shipIds = new ArrayList<>();
		List<Shipments> ships = shiprepo.findAll();

		System.out.println("Sssss::::" + ships);
		if (ships.isEmpty()) {

			System.out.println("In IF Condition");
			Collections.reverse(shipIds);
			String lastId = "T0000000";
			String[] splitLastId = lastId.split("T");
			for (String s : splitLastId) {
				afterSplit = s;
			}
			Integer splitInt = Integer.parseInt(afterSplit);
			Integer increment = splitInt + 1;
			String incrementString = increment.toString();
			System.out.println(incrementString);
			if (incrementString.length() == 1) {
				addZeros = "0000000";
			} else if (incrementString.length() == 2) {
				addZeros = "000000";
			} else if (incrementString.length() == 3) {
				addZeros = "00000";
			} else if (incrementString.length() == 4) {
				addZeros = "0000";
			} else if (incrementString.length() == 5) {
				addZeros = "000";
			} else if (incrementString.length() == 6) {
				addZeros = "00";
			} else if (incrementString.length() == 7) {
				addZeros = "0";
			} else if (incrementString.length() == 8) {
				throw new Exception("Its beyong the Limit of the Present One");
			}
			String finalString = "T";
			finalString = finalString.concat(addZeros).concat(incrementString);
			System.out.println(finalString);
			return finalString;
		} else {

			for (Shipments sh : ships) {
				sid = sh.getShipment_Id();
				shipIds.add(sid);
			}
			Collections.reverse(shipIds);
			String lastId = shipIds.get(0);
			String[] splitLastId = lastId.split("T");
			for (String s : splitLastId) {
				afterSplit = s;
			}
			Integer splitInt = Integer.parseInt(afterSplit);
			Integer increment = splitInt + 1;
			String incrementString = increment.toString();
			System.out.println(incrementString);
			if (incrementString.length() == 1) {
				addZeros = "0000000";
			} else if (incrementString.length() == 2) {
				addZeros = "0000000";
			} else if (incrementString.length() == 3) {
				addZeros = "000000";
			} else if (incrementString.length() == 4) {
				addZeros = "00000";
			} else if (incrementString.length() == 5) {
				addZeros = "0000";
			} else if (incrementString.length() == 6) {
				addZeros = "000";
			} else if (incrementString.length() == 6) {
				addZeros = "00";
			} else if (incrementString.length() == 7) {
				addZeros = "0";
			} else if (incrementString.length() == 8) {
				throw new Exception("Its beyong the Limit of the Present One");
			}
			String finalString = "T";
			finalString = finalString.concat(addZeros).concat(incrementString);
			System.out.println(finalString);
			return finalString;
		}
	}

	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDDData/{Customer_Id}") public DropDownShipmentDetails
	 * getDDData(@PathVariable(value = "Customer_Id") String Customer_id) throws
	 * Exception {
	 * 
	 * String generatedInternalShipmentId = generateInternalShipmentId();
	 * System.out.println(generatedInternalShipmentId);
	 * 
	 * List<CustomBP> listbp = new ArrayList<>(); BusinessPartner partner = null;
	 * CustomBP custBpp = null; DropDownShipmentDetails dp =
	 * ddrepo1.findByCustomer_id(Customer_id.trim()); String[] list3 =
	 * dp.getBusiness_Partner_Id(); List<String> list4 = convertArrayTOList(list3);
	 * System.out.println(list4); for (String ar : list4) { custBpp = new
	 * CustomBP(); partner = bussinesRepo.findByBP_Id(ar.trim());
	 * System.out.println(partner.getBP_Id()); if (partner.getBP_Id().equals(ar) &&
	 * !listbp.contains(partner.getBP_Id())) { if
	 * (listbp.contains(partner.getBP_Id())) { break; } else {
	 * custBpp.setBP_Id(partner.getBP_Id());
	 * custBpp.setCompany_Name(partner.getCompany_Name());
	 * custBpp.setEvents(partner.getEvents()); listbp.add(custBpp); } } }
	 * System.out.println(listbp); dp.setBussinesPartnersDetails(listbp);
	 * dp.setInternalShipmentId(generatedInternalShipmentId); return dp; }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDDData/{Customer_Id}") public DropDownShipmentDetails
	 * getDDData(@PathVariable(value = "Customer_Id") String Customer_id) throws
	 * Exception {
	 * 
	 * String generatedInternalShipmentId = generateInternalShipmentId();
	 * System.out.println(generatedInternalShipmentId);
	 * 
	 * List<CustomBP> listbp = new ArrayList<>(); BusinessPartner partner = null;
	 * CustomBP custBpp = null; DropDownShipmentDetails dp = null; String dms=null;
	 * 
	 * 
	 * 
	 * // System.out.println("Device_Id"+dp.getDevice_Id()[1]); // String[]
	 * Devicelist =dp.getDevice_Id(); dp =
	 * ddrepo1.findByCustomer_id(Customer_id.trim());
	 * 
	 * List<String> Devicelist =dp.getDevice_Id(); List<String> deviceIDs = new
	 * ArrayList<String>();
	 * 
	 * 
	 * //for(String cus: deviceIDs) { for (int i=0;i<Devicelist.size();i++) {
	 * 
	 * Devices dev = devicerepo.findByDevice_Id(Devicelist.get(i));
	 * //System.out.println("List Values:::"+dev.getDeviceStatusReferred());
	 * 
	 * 
	 * 
	 * 
	 * String status=dev.getDeviceStatusReferred();
	 * 
	 * 
	 * if(status.equals("Available")) {
	 * 
	 * dms = Devicelist.get(i);
	 * 
	 * deviceIDs.add(dms);
	 * 
	 * 
	 * 
	 * System.out.println("after else"); String[] list3 =
	 * dp.getBusiness_Partner_Id(); List<String> list4 = convertArrayTOList(list3);
	 * //System.out.println("Number:::"+list4); for (String ar : list4) { custBpp =
	 * new CustomBP(); partner = bussinesRepo.findByBP_Id(ar.trim());
	 * //System.out.println("BusinessPartner:::"+partner.getBP_Id()); if
	 * (partner.getBP_Id().equals(ar) && !listbp.contains(partner.getBP_Id())) { if
	 * (listbp.contains(partner.getBP_Id())) { break; } else {
	 * custBpp.setBP_Id(partner.getBP_Id());
	 * custBpp.setCompany_Name(partner.getCompany_Name());
	 * custBpp.setEvents(partner.getEvents()); listbp.add(custBpp); } } }
	 * //System.out.println(listbp); dp.setBussinesPartnersDetails(listbp);
	 * dp.setInternalShipmentId(generatedInternalShipmentId);
	 * 
	 * 
	 * 
	 * 
	 * //String[] listdev = dms.split(","); dp.setDevice_Id(deviceIDs);
	 * 
	 * }else { System.out.println("not in available"); }
	 * 
	 * } return dp; }
	 */
	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getDDData/{Customer_Id}") public DropDownShipmentDetails
	 * getDDData(@PathVariable(value = "Customer_Id") String Customer_id) throws
	 * Exception {
	 * 
	 * String generatedInternalShipmentId = generateInternalShipmentId();
	 * System.out.println(generatedInternalShipmentId);
	 * 
	 * List<CustomBP> listbp = new ArrayList<>(); BusinessPartner partner = null;
	 * CustomBP custBpp = null; DropDownShipmentDetails dp = null;
	 * 
	 * String dms = null;
	 * 
	 * // System.out.println("Device_Id"+dp.getDevice_Id()[1]); // String[]
	 * Devicelist =dp.getDevice_Id(); dp =
	 * ddrepo1.findByCustomer_id(Customer_id.trim());
	 * 
	 * List<String> Devicelist = dp.getDevice_Id(); List<String> deviceIDs = new
	 * ArrayList<String>();
	 * 
	 * // for(String cus: deviceIDs) { for (int i = 0; i < Devicelist.size(); i++) {
	 * 
	 * Devices dev = devicerepo.findByDevice_Id(Devicelist.get(i));
	 * //System.out.println("List Values:::" + dev.getDeviceStatusReferred());
	 * String status = dev.getDeviceStatusReferred();
	 * 
	 * 
	 * System.out.println("status " + status); if (status.equals("Available")) {
	 * 
	 * dms = Devicelist.get(i); System.out.println("adfr " + status);
	 * deviceIDs.add(dms); System.out.println("ajdhbfjda " + deviceIDs);
	 * 
	 * } else {
	 * 
	 * System.out.println("not in available"); dp.setDevice_Id(null); }
	 * 
	 * System.out.println("after else"); String[] list3 =
	 * dp.getBusiness_Partner_Id(); List<String> list4 = convertArrayTOList(list3);
	 * // System.out.println("Number:::"+list4); for (String ar : list4) { custBpp =
	 * new CustomBP(); partner = bussinesRepo.findByBP_Id(ar.trim()); //
	 * System.out.println("BusinessPartner:::"+partner.getBP_Id()); if
	 * (partner.getBP_Id().equals(ar) && !listbp.contains(partner.getBP_Id())) { if
	 * (listbp.contains(partner.getBP_Id())) { break; } else {
	 * custBpp.setBP_Id(partner.getBP_Id());
	 * custBpp.setCompany_Name(partner.getCompany_Name());
	 * custBpp.setEvents(partner.getEvents()); listbp.add(custBpp); } } } //
	 * System.out.println(listbp); dp.setBussinesPartnersDetails(listbp);
	 * dp.setInternalShipmentId(generatedInternalShipmentId);
	 * dp.setDevice_Id(deviceIDs);
	 * 
	 * // String[] listdev = dms.split(",");
	 * 
	 * } return dp; }
	 */
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getDDData/{Customer_Id}")
	public DropDownShipmentDetails getDDData(@PathVariable(value = "Customer_Id") String Customer_id) throws Exception {

		String generatedInternalShipmentId = generateInternalShipmentId();
		System.out.println(generatedInternalShipmentId);

		List<CustomBP> listbp = new ArrayList<>();
		BusinessPartner partner = null;
		CustomBP custBpp = null;
		DropDownShipmentDetails dp = null;

		String dms = null;

		// System.out.println("Device_Id"+dp.getDevice_Id()[1]);
		// String[] Devicelist =dp.getDevice_Id();
		dp = ddrepo1.findByCustomer_id(Customer_id.trim());
		System.out.println("kjaksd" + dp);
		List<String> Devicelist = dp.getDevice_Id();
		List<String> deviceIDs = new ArrayList<String>();
		System.out.println("dfgdfg" + Devicelist);
		if (Devicelist == null) {

			dp.setDevice_Id(null);

			System.out.println("If Devices Not Available");
			List<BPList> list4 = dp.getBusinessPartner();
			// List<String> list4 = convertArrayTOList(list3);
			System.out.println("Number:::" + list4);
			for (BPList ar : list4) {
				custBpp = new CustomBP();
				partner = bussinesRepo.findByBP_Id(ar.getBP_Id());
				System.out.println("BusinessPartner:::" + partner.getBP_Id());
				System.out.println("BusinessPartner:::" + ar.getBP_Id());

				if (partner.getBP_Id().equals(ar.getBP_Id()) && !listbp.contains(partner.getBP_Id())) {

					System.out.println("if condition");

					if (listbp.contains(partner.getBP_Id())) {
						break;
					} else {
						custBpp.setBP_Id(partner.getBP_Id());
						custBpp.setCompany_Name(partner.getCompany_Name());
						custBpp.setEvents(partner.getEvents());
						listbp.add(custBpp);
					}
				}

			}
			// System.out.println(listbp);
			dp.setBussinesPartnersDetails(listbp);
			dp.setInternalShipmentId(generatedInternalShipmentId);

			// dp.setDevice_Id(deviceIDs);

		} else {

			// for(String cus: deviceIDs) {
			for (int i = 0; i < Devicelist.size(); i++) {
				System.out.println("sjm,fbdsjhf" + Devicelist.get(i));
				Devices dev = devicerepo.findByDevice_Id(Devicelist.get(i));

				System.out.println("List Values:::" + dev);

				String status = dev.getDeviceStatusReferred();

				System.out.println("Status::::" + status);
				if (status.equals("Available")) {

					dms = Devicelist.get(i);

					deviceIDs.add(dms);

				} else {

					System.out.println("not in available");
					dp.setDevice_Id(null);
				}

				System.out.println("after else");
				List<BPList> list3 = dp.getBusinessPartner();
				// List<String> list4 = convertArrayTOList(list3);
				// System.out.println("Number:::"+list4);
				for (BPList ar : list3) {
					custBpp = new CustomBP();
					System.out.println("BusinessPartner:::" + ar.getBP_Id());
					partner = bussinesRepo.findByBP_Id(ar.getBP_Id());
					System.out.println("BusinessPartner:::" + partner.getBP_Id());
					if (partner.getBP_Id().equals(ar.getBP_Id()) && !listbp.contains(partner.getBP_Id())) {
						if (listbp.contains(partner.getBP_Id())) {
							break;
						} else {
							custBpp.setBP_Id(partner.getBP_Id());
							custBpp.setCompany_Name(partner.getCompany_Name());
							custBpp.setEvents(partner.getEvents());
							listbp.add(custBpp);
						}
					}
				}
				// System.out.println(listbp);
				dp.setBussinesPartnersDetails(listbp);
				dp.setInternalShipmentId(generatedInternalShipmentId);

				dp.setDevice_Id(deviceIDs);

				// String[] listdev = dms.split(",");

			}

		}
		return dp;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getSavedDraft/{Internal_Shipment_Id}")
	public ShipmentDraftDto getSavedDraft(@PathVariable(value = "Internal_Shipment_Id") String Internal_Shipment_id) {
		return savedraftRepo.findByInternal_Shipment_id(Internal_Shipment_id);
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/customerGetSavedDraft/{Customer_Id}")
	public List<ShipmentDraftDto> customerGetSavedDraft(@PathVariable(value = "Customer_Id") String Customer_Id) {
		return savedraftRepo.findByCustomer_Id(Customer_Id);
	}
	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getAllDrafts") public List<ShipmentDraftDto>
	 * getAllSavedDrafts() { return savedraftRepo.findAll(); }
	 */

	//////////////////////////// These are the Wrong Data Model for the Shipment
	//////////////////////////// --- For the Initial Requirment
	//////////////////////////// so Please exempt its ////////////////////

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getDropdowndata/{Dp_Id}")
	public DropDownDto getddData(@PathVariable(value = "Dp_Id") String Dp_id) {
		return dprepo.findByDp_id(Dp_id.trim());

	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/createShipmentDraft")
	public boolean createShipmentDrafts(@Validated @RequestBody  ShipmentDrafts drafts) {

		System.out.println();
		boolean flag = false;
		ShipmentDrafts sd;
		try {
			// Form Validation should be done at Frontend
			if (drafts.getInternal_Shipment_Id() != null) {
				System.out.println("Finding weather the Shipment Number Exists or Not");
				List<ShipmentDrafts> Slist = shipmentDraftsRepo.findAll();
				for (ShipmentDrafts duList : Slist) {
					if (duList.getShipment_Number().equals(drafts.getShipment_Number())) {
						System.out.println("The Shipment Number already exists .. so Please another Shipment Number");
						flag = false;
						return flag;
					}
				}
				System.out.println("data validated going to create Shipment");
				sd = shipmentDraftsRepo.insert(drafts);
				System.out.println("data persisted");
				flag = true;
			} else {
				System.out.println("Please send the valid data");
				flag = false;
			}
		} catch (Exception e) {
		}
		return flag;

	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getDraftData/{Internal_Shipment_Id}")
	public ShipmentDraftPartialGet getPartiallySavedData(
			@PathVariable(value = "Internal_Shipment_Id") String Internal_Shipment_id) {
		return shipmentDraftsRepo.findByInternal_Shipment_id(Internal_Shipment_id);
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/updateShipmentEvent")
	public boolean updateShipmentEvent(@Validated @RequestBody UpdateShipmentEvent updateEvent) {
		boolean flag = false;
		try {
			List<CreateShipment> list1 = completeShipRepo.findAll();
			for (CreateShipment ships : list1) {
				if (ships.getShipment_Number().equals(updateEvent.getShipment_Number())) {
					System.out.println("Shipment exists");
				}
			}
			System.out.println("Going to Update");
			Query query = new Query(Criteria.where("Shipment_Number").is(updateEvent.getShipment_Number()));
			Update update = new Update();
			update.set("TypeOfReference", updateEvent.getTypeOfReference());
			update.set("ShipmentDescription", updateEvent.getShipmentDescription());
			update.set("EventId", updateEvent.getEventId());
			update.set("EventType", updateEvent.getEventType());
			update.set("PartnerFrom", updateEvent.getPartnerFrom());
			update.set("EventReferenceNumber", updateEvent.getEventReferenceNumber());
			update.set("EventDescription", updateEvent.getEventDescription());
			System.out.println(update);
			mongoTemplate.updateMulti(query, update, "CreateShipment");
			flag = true;

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return flag;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/completeShipment")
	public boolean completeShipment(@Validated @RequestBody CompleteShipmentDto completeDto) {
		boolean flag = false;
		try {
			List<CreateShipment> list1 = completeShipRepo.findAll();
			for (CreateShipment ships : list1) {
				if (ships.getShipment_Number().equals(completeDto.getShipment_Number())) {
					System.out.println("Shipment exists");
				}
			}
			System.out.println("Going to Update");
			Query query = new Query(Criteria.where("Shipment_Id").is(completeDto.getShipment_Number()));
			Update update = new Update();
			update.set("TypeOfReference", completeDto.getTypeOfReference());
			update.set("ReceivingLocation", completeDto.getReceivingLocation());
			update.set("ReceivingReferenceNumber", completeDto.getReceivingReferenceNumber());
			update.set("ReceivingDescription", completeDto.getReceivingDescription());
			update.set("DeviceReturnLocation", completeDto.getDeviceReturnLocation());
			System.out.println(update);
			mongoTemplate.updateMulti(query, update, "CreateShipment");
			flag = true;

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return flag;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/createFinalShipment")
	public boolean createShipment(@Validated @RequestBody ShipmentDrafts event) {

		CreateShipment fullShip = new CreateShipment();
		boolean flag = false;
		try {
			List<CreateShipment> drafts = completeShipRepo.findAll();
			for (CreateShipment ships : drafts) {
				if (ships.getShipment_Number().equals(event.getShipment_Number())) {
					System.out.println("Shipment Already exists");
					flag = false;
					return flag;
				}
			}
			fullShip.setInternal_Shipment_Id(event.getInternal_Shipment_Id());
			fullShip.setCustomerName(event.getCustomerName());
			fullShip.setPartnerName(event.getPartnerName());
			fullShip.setTempRange(event.getTempRange());
			fullShip.setRhrange(event.getRhrange());
			fullShip.setMode(event.getMode());
			fullShip.setInco(event.getInco());
			fullShip.setShipment_Number(event.getShipment_Number());
			fullShip.setTypeOfReference(event.getTypeOfReference());
			fullShip.setRouteDetails(event.getRouteDetails());
			fullShip.setDestination(event.getDestination());
			fullShip.setGoodsType(event.getGoodsType());
			fullShip.setExpectedDelDate(event.getExpectedDelDate());
			fullShip.setAddTagInfo(event.getAddTagInfo());

			// Update event Shipment
			fullShip.setEventId("");
			fullShip.setEventType("");
			fullShip.setPartnerFrom("");
			fullShip.setEventReferenceNumber("");
			fullShip.setEventDescription("");

			// Complete Shipment
			fullShip.setReceivingLocation("");
			fullShip.setReceivingReferenceNumber("");
			fullShip.setReceivingDescription("");
			fullShip.setDeviceReturnLocation("");
			completeShipRepo.insert(fullShip);
			flag = true;

		} catch (Exception e) {
			System.out.println("please enter valid data");
		}

		return flag;
	}

	// getShipmentTransaction and deviceDatastream data
	// DeviceData RestEndPoint
	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getShipmentTransaction1/{Customer_Id}")
	public List<ShipmentTransactionDeviceData> getShipmentTransactionDeviceData(
			@PathVariable(value = "Customer_Id") String Customer_Id) {
		System.out.println("Customer_ID" + Customer_Id);
		List<ShipmentTransactionDeviceData> shiptranDevData = new ArrayList<ShipmentTransactionDeviceData>();
		List<ShipmentTransactions> shipTrans = new ArrayList<ShipmentTransactions>();
		List<DeviceDataStream> Aldds = new ArrayList<DeviceDataStream>();

		shipTrans = shiptransrepo.findByCustomer_Id(Customer_Id);

		Aldds = devicedatarepo.getShipmentTransactionDeviceData(shipTrans.get(0).getDevice_Id().trim());
		System.out.println("SSSS:::" + Aldds);
		for (DeviceDataStream Alds : Aldds) {

			for (ShipmentTransactions shpTran : shipTrans) {

				ShipmentTransactionDeviceData shpTranDD = new ShipmentTransactionDeviceData();
				shpTranDD.setShipment_Id(shpTran.getShipment_Id());
				shpTranDD.setShipment_Num(shpTran.getShipment_Num());
				shpTranDD.setEvent_Name(shpTran.getEvent_Name());
				shpTranDD.setMode_of_Transport(shpTran.getMode_of_Transport());
				shpTranDD.setDevice_Id(Alds.getDevice_Id());
				shpTranDD.setBatteryLevel(Alds.getBattery_Level());// shpTranDD.setAltitude(Alds.getAltitude());
//	shpTranDD.setBAT(Alds.getBattery_Level());
//	shpTranDD.setDistance(Alds.getDistance());
//	shpTranDD.setInternal_temperature(Alds.getInternal_temperature());
//	shpTranDD.setLatitude(Alds.getLatitude_in_space());
//	shpTranDD.setLongitude(Alds.getLongitude());
//	shpTranDD.setMessage_Number(Alds.getMessage_Number());
//	shpTranDD.setReport_type(Alds.getReport_type());
//	shpTranDD.setSensor_id(Alds.getSensor_id());
//	shpTranDD.setSpeed(Alds.getSpeed());
//	shpTranDD.setTemp_Measurment(Alds.getTemp_Measurment());
				shpTranDD.setUTC(Alds.getCurrent_terminal_time());
				shpTranDD.setInternal_temperature(Alds.getInternal_temperature());
				shiptranDevData.add(shpTranDD);
			}

		}

		return shiptranDevData;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getShipmentTransactionhistory/{Shipment_Id}")
	public List<ShipmentTransactions> getshipmentstranshistory(@PathVariable String Shipment_Id) {

		List<ShipmentTransactions> sp = shiptransrepo.findByShipment_Id(Shipment_Id.trim());
		List<ShipmentTransactions> shiptranDevData = new ArrayList<ShipmentTransactions>();
		ShipmentTransactions shiphisto = new ShipmentTransactions();
		for (ShipmentTransactions shpTran : sp) {
			shiphisto.setShipment_Id(shpTran.getShipment_Id());
			shiphisto.setShipment_Num(shpTran.getShipment_Num());
			shiphisto.setEvent_Name(shpTran.getEvent_Name());
			shiphisto.setMode_of_Transport(shpTran.getMode_of_Transport());
			shiphisto.setCustomer_Id(shpTran.getCustomer_Id());
			shiphisto.setEvent_SNo(shpTran.getEvent_SNo());
			shiphisto.setDevice_Id(shpTran.getDevice_Id());
			shiphisto.setShip_Date_From_BP(shpTran.getShip_Date_From_BP());
			shiphisto.setExpected_Date_At_BP(shpTran.getExpected_Date_At_BP());
			shiphisto.setPartner_From(shpTran.getPartner_From());
			shiphisto.setPartner_To(shpTran.getPartner_To());
			shiphisto.setEvent_Status(shpTran.getEvent_Status());
			shiphisto.setComments(shpTran.getComments());
			shiphisto.setEvent_Exec_Date(shpTran.getEvent_Exec_Date());
			shiphisto.setTypeOfReference(shpTran.getTypeOfReference());
			shiphisto.setEventReferenceNumber(shpTran.getEventReferenceNumber());
			shiptranDevData.add(shiphisto);
		}
		return sp;
	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getShipmentTransactionDeviceDataLast/{Shipment_Id}")
	public List<ShipmentTransactionDeviceData> getShipmentTransactionLast(
			@PathVariable(value = "Shipment_Id") String Shipment_Id) {

		List<ShipmentTransactionDeviceData> shiptranDevData = new ArrayList<ShipmentTransactionDeviceData>();		
		List<ShipmentTransactions> shipTrans = new ArrayList<ShipmentTransactions>();		
		DeviceDataStream dds = new DeviceDataStream();

		shipTrans = shiptransrepo.findByShipment_Id(Shipment_Id.trim());
		Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id);
		
		
		if (shipTrans.size() != 0) {

			dds = devicedatarepo.getDeviceDataStreamSingleDocumentDate(shipTrans.get(0).getDevice_Id().trim());
			ShipmentTransactionDeviceData shpTranDD = new ShipmentTransactionDeviceData();
			for (ShipmentTransactions shpTran : shipTrans) {
				System.out.println("ShipmentTransactions -----complete::::     " + shpTran);
				if (shpTran.getEvent_Status().equals("Initialized")) {

					break;
				}

				shpTranDD.setShipment_Id(shpTran.getShipment_Id());
				shpTranDD.setShipment_Num(shpTran.getShipment_Num());
				shpTranDD.setEvent_Name(shpTran.getEvent_Name());
				shpTranDD.setEvent_SNo(shpTran.getEvent_SNo());
				shpTranDD.setEvent_Status(shpTran.getEvent_Status());
				shpTranDD.setEvent_Exec_Date(shpTran.getEvent_Exec_Date());
				shpTranDD.setMode_of_Transport(shpTran.getMode_of_Transport());
				
				shpTranDD.setPo_Number(shipment.getPo_Number());
				shpTranDD.setNdc_Number(shipment.getNdc_Number());
				shpTranDD.setInvoice_Number(shipment.getInvoice_Number());
				shpTranDD.setShipper_Number(shipment.getShipper_Number());
				shpTranDD.setSerial_Number_of_goods(shipment.getSerial_Number_of_goods());
				shpTranDD.setBatch_Id(shipment.getBatch_Id());
				shpTranDD.setCmo_Ref_Number(shipment.getCmo_Ref_Number());
				try {
				     String dateStr = shipment.getEstimated_Delivery_Date();
			         SimpleDateFormat sdf_created = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			         Date date_created = sdf_created.parse(dateStr);
			         sdf_created = new SimpleDateFormat("yyyy-MM-dd");
			         dateStr = sdf_created.format(date_created);
			    
				     shpTranDD.setEstimated_Delivery_Date(dateStr);
				}
				catch (Exception e){
					 System.out.println(e +"  Parse Exception in Estimated Delivery Date");
				}
				shpTranDD.setRoute_Details(shipment.getRoute_From()+"-"+shipment.getRoute_To());
				shpTranDD.setGoods_Type(shipment.getGoods_Desc());
				try {
				shpTranDD.setBatteryLevel(String.valueOf(100 * Float.valueOf(dds.getBattery_Level()) - 318));
				}
				catch(Exception e) {
					System.out.println(e+ "  Null pointer Exception in Battery Level");
				}
				//shpTranDD.setDevice_Id(shpTran.getDevice_Id());

				if(!shpTran.getDevice_Id().equals(null) || !shpTran.getDevice_Id().equals("")) {
					
					shpTranDD.setDevice_Id(shpTran.getDevice_Id());
					break;			
				}else {
					shpTranDD.setDevice_Id("Device is not Attached");
					
				}
		
				// shpTranDD.setAltitude(dds.getAltitude());
			    //shpTranDD.setBatteryLevel(dds.getBattery_Level());
//				shpTranDD.setBatteryLevel(String.valueOf(100 * Float.valueOf(dds.getBattery_Level()) - 318));
				System.out.println("Batterylevel::::" + dds.getBattery_Level());
				shpTranDD.setDistance(dds.getReportDistance());
				shpTranDD.setInternal_temperature(dds.getInternal_temperature());
				shpTranDD.setLatitude(dds.getLatitude());
				shpTranDD.setLongitude(dds.getLongitude());
				shpTranDD.setMessage_Number(dds.getMessage_Type());
				shpTranDD.setReport_type(dds.getReport_type());
				shpTranDD.setSensor_id(dds.getSensorUTC());
				shpTranDD.setSpeed(dds.getSpeed_in_mph());
				// shpTranDD.setTemp_Measurment(dds.getTemp_Measurment());
				shpTranDD.setUTC(dds.getSensorUTC());
				shpTranDD.setPartner_From(shpTran.getPartner_From());
				shpTranDD.setPartner_To(shpTran.getPartner_To());
      			shpTranDD.setAddress(dds.getAddress());
//				shpTranDD.setPo_Number(shipment.getPo_Number());
//				shpTranDD.setNdc_Number(shipment.getNdc_Number());
//				shpTranDD.setInvoice_Number(shipment.getInvoice_Number());
//				shpTranDD.setShipper_Number(shipment.getShipper_Number());
//				shpTranDD.setSerial_Number_of_goods(shipment.getSerial_Number_of_goods());
//				shpTranDD.setBatch_Id(shipment.getBatch_Id());
//				shpTranDD.setCmo_Ref_Number(shipment.getCmo_Ref_Number());
			}
			shiptranDevData.add(shpTranDD);
		

		}
		System.out.println("returns::::" + shiptranDevData);
		return shiptranDevData;
		

	}
	/*
	 * @ResponseBody
	 * 
	 * @GetMapping("/getShipmentTransactionDeviceData/{Shipment_Id}") public
	 * List<ShipmentTransactionDeviceData>
	 * getShipmentTransaction(@PathVariable(value = "Shipment_Id") String
	 * Shipment_Id) {
	 * 
	 * List<ShipmentTransactionDeviceData> shiptranDevData = new
	 * ArrayList<ShipmentTransactionDeviceData>(); List<ShipmentTransactions>
	 * shipTrans = new ArrayList<ShipmentTransactions>(); List<DeviceDataStream>dds=
	 * new ArrayList<DeviceDataStream>(); //List<DeviceDataStream> dds = new Arra
	 * DeviceDataStream();
	 * 
	 * shipTrans = shiptransrepo.findByShipment_Id(Shipment_Id.trim());
	 * 
	 * if(shipTrans.size()!=0){
	 * 
	 * 
	 * dds =
	 * devicedatarepo.getShipmentTransactionDeviceData(shipTrans.get(0).getDevice_Id
	 * ().trim());
	 * 
	 * for(ShipmentTransactions shpTran : shipTrans){ for(DeviceDataStream
	 * devicestream :dds) {
	 * 
	 * 
	 * 
	 * 
	 * ShipmentTransactionDeviceData shpTranDD = new
	 * ShipmentTransactionDeviceData();
	 * 
	 * shpTranDD.setShipment_Id(shpTran.getShipment_Id());
	 * shpTranDD.setShipment_Num(shpTran.getShipment_Num());
	 * shpTranDD.setEvent_Name(shpTran.getEvent_Name());
	 * shpTranDD.setEvent_SNo(shpTran.getEvent_SNo());
	 * shpTranDD.setMode_of_Transport(shpTran.getMode_of_Transport());
	 * shpTranDD.setDevice_Id(shpTran.getDevice_Id()); //
	 * shpTranDD.setAltitude(dds.getAltitude()); // shpTranDD.setBAT(dds.getBAT());
	 * // shpTranDD.setDistance(dds.getDistance());
	 * shpTranDD.setInternal_temperature(devicestream.getInternal_temperature());
	 * shpTranDD.setLatitude(devicestream.getLatitude());
	 * shpTranDD.setLongitude(devicestream.getLongitude()); //
	 * shpTranDD.setMessage_Number(dds.getMessage_Number()); //
	 * shpTranDD.setReport_type(dds.getReport_type()); //
	 * shpTranDD.setSensor_id(dds.getSensor_id()); //
	 * shpTranDD.setSpeed(dds.getSpeed());
	 * //shpTranDD.setTemp_Measurment(dds.getTemp_Measurment());
	 * shpTranDD.setUTC(devicestream.getUTC());
	 * shpTranDD.setAddress(devicestream.getAddress());
	 * shpTranDD.setPartner_From(shpTran.getPartner_From());
	 * shpTranDD.setPartner_To(shpTran.getPartner_To());
	 * shiptranDevData.add(shpTranDD); } }
	 * 
	 * }
	 * 
	 * return shiptranDevData;
	 * 
	 * }
	 */
	// getShipmentTransaction and deviceDatastream data
	// DeviceData RestEndPoint

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getShipmentTransactionDeviceData/{Shipment_Id}")
	public List<ShipmentTransactionDeviceData> getShipmentTransaction(
			@PathVariable(value = "Shipment_Id") String Shipment_Id) {

		List<ShipmentTransactionDeviceData> shiptranDevData = new ArrayList<ShipmentTransactionDeviceData>();
		List<ShipmentTransactions> shipTrans = new ArrayList<ShipmentTransactions>();
		DeviceDataStream dds = new DeviceDataStream();

		shipTrans = shiptransrepo.findByShipment_Id(Shipment_Id.trim());
		Shipments shipment = shiprepo.findByShipment_Id(Shipment_Id);

		if (shipTrans.size() != 0) {

			dds = devicedatarepo.getDeviceDataStreamSingleDocumentDate(shipTrans.get(0).getDevice_Id().trim());
			System.out.println("smndjbfks" + shipTrans.get(0).getDevice_Id().trim());
//			System.out.println("smndjbfks" + dds.getLatitude());
			ShipmentTransactionDeviceData shpTranDD = new ShipmentTransactionDeviceData();
			for (ShipmentTransactions shpTran : shipTrans) {
//				System.out.println("sk,dfj" + dds.getLatitude());
//				ShipmentTransactionDeviceData shpTranDD = new ShipmentTransactionDeviceData();
				shpTranDD.setShipment_Id(shpTran.getShipment_Id());
				shpTranDD.setShipment_Num(shpTran.getShipment_Num());
				shpTranDD.setEvent_Name(shpTran.getEvent_Name());
				shpTranDD.setEvent_SNo(shpTran.getEvent_SNo());
				shpTranDD.setEvent_Status(shpTran.getEvent_Status());
				shpTranDD.setEvent_Exec_Date(shpTran.getEvent_Exec_Date());
				shpTranDD.setMode_of_Transport(shpTran.getMode_of_Transport());
				shpTranDD.setDevice_Id(shpTran.getDevice_Id()); //

				// shpTranDD.setAltitude(dds.getAltitude());
				// shpTranDD.setBAT(dds.getBAT());
				// shpTranDD.setDistance(dds.getReportDistance());
				// shpTranDD.setInternal_temperature(dds.getInternal_temperature());
				try {
				shpTranDD.setLatitude(dds.getLatitude());
				shpTranDD.setLongitude(dds.getLongitude());
				// shpTranDD.setMessage_Number(dds.getMessageType()); //
				shpTranDD.setReport_type(dds.getReport_type());
				shpTranDD.setSensor_id(dds.getSensorUTC());
				shpTranDD.setSpeed(dds.getSpeed_in_mph()); //
				// shpTranDD.setTemp_Measurment(dds.getTemp_Measurment());
				shpTranDD.setUTC(dds.getSensorUTC());
				shpTranDD.setPartner_From(shpTran.getPartner_From());
				shpTranDD.setPartner_To(shpTran.getPartner_To());
				shpTranDD.setAddress(dds.getAddress());
				shpTranDD.setBatteryLevel(String.valueOf(100 * Float.valueOf(dds.getBattery_Level()) - 318));
				}
				catch(Exception e) {
					System.out.println(e);
					System.out.println("Exception in Device Data- getShipmentTransactionDeviceData");
				}
//				shpTranDD.setBatteryLevel(String.valueOf(100 * Float.valueOf(dds.getBattery_Level()) - 318));			
				shpTranDD.setPo_Number(shipment.getPo_Number());
				shpTranDD.setNdc_Number(shipment.getNdc_Number());
				shpTranDD.setInvoice_Number(shipment.getInvoice_Number());
				shpTranDD.setShipper_Number(shipment.getShipper_Number());
				shpTranDD.setSerial_Number_of_goods(shipment.getSerial_Number_of_goods());
											
//				shiptranDevData.add(shpTranDD);
			}
			shiptranDevData.add(shpTranDD);
		}

		return shiptranDevData;

	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/getWayInfo/{Shipment_Id}")
	public Set<ShipmentWayinfo> getWayInfo(@PathVariable(value = "Shipment_Id") String Shipment_Id) {

		List<ShipmentWayinfo> devicdatalist = new ArrayList<>();

		List<DeviceDataStream> deviceinfo = new ArrayList<>();

		List<String[]> arraydata = null;
		Shipments shipdetails = shiprepo.findByShipment_Id(Shipment_Id.trim());

		String Device_id = shipdetails.getDevice_Id();
		String Created_Date = shipdetails.getCreated_Date();

		deviceinfo = devicedatarepo.getShipmentTransactionDeviceData(Device_id);

		arraydata = devicedatarepo.getlatLong(Device_id, Created_Date);

		for (String[] datastream : arraydata) {

			ShipmentWayinfo shiptranDevData = new ShipmentWayinfo();
			shiptranDevData.setDevice_Id(datastream[4]);
			shiptranDevData.setAddress(datastream[2]);
			shiptranDevData.setShipment_Num(shipdetails.getShipment_Num());
			shiptranDevData.setSensorUTC(datastream[3]);

			// devicelist.add(devicdatalist);

			String latlong = datastream[0] + "," + datastream[1];

			// String[] s=latlong.split(",");

			shiptranDevData.setWayPoints(latlong);
			devicdatalist.add(shiptranDevData);

		}

		Set<ShipmentWayinfo> devicelist = new LinkedHashSet<ShipmentWayinfo>(devicdatalist);

		/*
		 * @ResponseBody
		 * 
		 * @GetMapping("/getCanCompleteShipment/{Shipment_Id}/{Login_Bp}") public
		 * CanCompleteShipmentDto CanCompleteShipment(@PathVariable(value =
		 * "Shipment_Id") String Shipment_Id,
		 * 
		 * @PathVariable(value = "Login_Bp") String Login_Bp) { CanCompleteShipmentDto
		 * dto = new CanCompleteShipmentDto(); List<ShipmentTransactions> sp = new
		 * ArrayList<>(); Criteria crt = new Criteria();
		 * crt.andOperator(Criteria.where("Shipment_Id").is(Shipment_Id)); Query query =
		 * new Query(crt); sp = mongoTemplate.find(query, ShipmentTransactions.class);
		 * for (ShipmentTransactions tr : sp) { if
		 * (tr.getEvent_Name().equals("Final Receipt") &&
		 * tr.getPartner_From().equals(Login_Bp)) { dto.setCanComplete(true); } }
		 * System.out.println(dto.isCanComplete()); if
		 * ("false".equals(dto.isCanComplete())) { dto.setCanComplete(false); } return
		 * dto; }
		 */

		return devicelist;

	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@PostMapping("/filterParam")
	public Response filterParameters(@Validated @RequestBody Search searchdto) throws Exception {

		Response response = new Response();
		Search searchparam = new Search();
		Customer customer = customerepo.findByCustomerId(searchdto.getCustomer_Id());

		try {

			if (customer.getCustomer_Id().equals(searchdto.getCustomer_Id())) {
				searchparam.setDeliveryNumber(searchdto.getDeliveryNumber());
				searchparam.setFrom(searchdto.getFrom());
				searchparam.setTo(searchdto.getTo());
				searchparam.setGoods(searchdto.getGoods());
				searchparam.setCustomer_Id(searchdto.getCustomer_Id());
				searchparam.setReference(searchdto.getReference());
				searchparam.setShipDate(searchdto.getShipDate());
				searchparam.setDevice(searchdto.getDevice());
				searchparam.setDept(searchdto.getDept());

				response.setStatus(true);
				response.setMessage("Passing the Parameters");
				return response;
			} else {
				response.setStatus(false);
				response.setMessage("please check your customer_Id");
				return response;
			}
		}

		catch (Exception e) {

		}

		return response;

	}

	@ResponseBody
	@PreAuthorize("hasAnyAuthority('SUPERADMIN', 'ADMIN', 'BUSINESSPARTNER')")
	@GetMapping("/searchfilter")
	public List<Shipments> searchfilter(@RequestParam Map<String, String> searchvalues) {

		System.out.println("In list" + searchvalues.get("from"));
		System.out.println("In list" + searchvalues.get("to"));

		List<Shipments> shipmentsdetails = new ArrayList<Shipments>();

		// List<Shipments>
		// searchdata=shiprepo.findByRoute_FromandRoute_To(Route_From,Route_To,Goods_Desc);
		Query query = new Query();

		if (searchvalues.get("from") != null) {
			Criteria nameCriteria = Criteria.where("Route_From")
					.is(Pattern.compile(searchvalues.get("from"), Pattern.CASE_INSENSITIVE));
			query.addCriteria(nameCriteria);
		}

		if (searchvalues.get("to") != null) {
			Criteria nameCriteria1 = Criteria.where("Route_To")
					.is(Pattern.compile(searchvalues.get("to"), Pattern.CASE_INSENSITIVE));
			query.addCriteria(nameCriteria1);
		}

		if (searchvalues.get("goods") != null) {
			Criteria nameCriteria2 = Criteria.where("Goods_Desc")
					.is(Pattern.compile(searchvalues.get("goods"), Pattern.CASE_INSENSITIVE));

			query.addCriteria(nameCriteria2);
		}
		if (searchvalues.get("Device_Id") != null) {
			Criteria nameCriteria3 = Criteria.where("Device_Id").is(searchvalues.get("Device_Id"));
			query.addCriteria(nameCriteria3);
		}
		if (searchvalues.get("Shipment_Num") != null) {
			Criteria nameCriteria4 = Criteria.where("Shipment_Num").is(searchvalues.get("Shipment_Num"));
			query.addCriteria(nameCriteria4);
		}
		if (searchvalues.get("Created_Date") != null) {
			String date[] = searchvalues.get("Created_Date").split("T");

			Criteria nameCriteria5 = Criteria.where("Created_Date")/* .is(date[0]+"T00:00:00.000Z") */
					.gte(date[0] + "T00:00:00.000Z");
			query.addCriteria(nameCriteria5);

		}
		/*
		 * if (searchvalues.get("Created_Date") != null) { Criteria nameCriteria5 =
		 * Criteria.where("Created_Date").is(searchvalues.get("Created_Date"));
		 * query.addCriteria(nameCriteria5); }
		 */
		if (searchvalues.get("Customer_Id") != null) {
			Criteria nameCriteria6 = Criteria.where("Customer_Id").is(searchvalues.get("Customer_Id"));
			query.addCriteria(nameCriteria6);
		}
		if (searchvalues.get("reference") != null) {
			Criteria nameCriteria6 = Criteria.where("Type_Of_Reference").is(searchvalues.get("reference"));
			query.addCriteria(nameCriteria6);
		}
		List<Shipments> response = new ArrayList<>();
		response = mongoTemplate.find(query, Shipments.class, "Shipments");
		System.out.println("response " + response);

		for (Shipments ship : response) {

			List<String[]> device = devicedatarepo.getlatLang(ship.getDevice_Id(), ship.getCreated_Date());
			ship.setWayPoints(device);
			ship.setEvent_Status(shiptransrepo.event_status(ship.getShipment_Id().trim()));
			ship.setDelivered_Status(ship.getShipment_Status());
			shipmentsdetails.add(ship);

		}

		return shipmentsdetails;
	}
	
	
	@ResponseBody
	@PostMapping("/excelfileupload")
	public  List<ErrorExcel> excelfile(@RequestParam("file") MultipartFile reapExcelDataFile) throws Exception {
		Date date = new Date();
		SimpleDateFormat formattr = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		String strDate = formattr.format(date);
		
		List<ErrorExcel> errorlist = new ArrayList<ErrorExcel>();			
		ErrorExcel errorexcel = new ErrorExcel();
		
    	ShipmentTransactions trans = null;	
		List<Shipments> shipmentsList = new ArrayList<Shipments>();			

		XSSFWorkbook workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
		XSSFSheet worksheet = workbook.getSheetAt(0);
//		XSSFRow row1 = worksheet.getRow(1);
//		Iterator<Cell> cells = row1.cellIterator();
		DataFormatter formatter = new DataFormatter();

		for(int i=1; i<worksheet.getPhysicalNumberOfRows() ;i++) {
			    errorexcel = new ErrorExcel();
			    trans = new ShipmentTransactions();
			    Shipments shpmtList = new Shipments();
		            
		        XSSFRow row = worksheet.getRow(i);
		        System.out.println(" no of physical cells in a row     "+row.getPhysicalNumberOfCells());
//		        System.out.println(" got columnNum'th cell in a row     "+row.getCell(columnNum));
		        
		        System.out.println(formatter.formatCellValue(row.getCell(0)));
		        System.out.println(formatter.formatCellValue(row.getCell(1)));
		        System.out.println(formatter.formatCellValue(row.getCell(2)));
		        System.out.println(formatter.formatCellValue(row.getCell(3)));
		        System.out.println(formatter.formatCellValue(row.getCell(4)));
		
		        if (row.getPhysicalNumberOfCells() == 5) {

		        System.out.println(formatter.formatCellValue(row.getCell(0)));
		        System.out.println(formatter.formatCellValue(row.getCell(1)));
		        System.out.println("00"+formatter.formatCellValue(row.getCell(2)));
		        System.out.println(formatter.formatCellValue(row.getCell(3)));
		        System.out.println(formatter.formatCellValue(row.getCell(4)));

		    	Query query_spid = new Query();
		    	query_spid.addCriteria(
						new Criteria().andOperator(Criteria.where("Invoice_Number").is(formatter.formatCellValue(row.getCell(0)))));
				List<Shipments> shpid = mongoTemplate.find(query_spid, Shipments.class);
				
				System.out.println("list shpid  ");
				System.out.println(shpid.isEmpty());
				System.out.println("getting shpid list  ");
				System.out.println(shpid);
				
				if(!shpid.isEmpty()) {
		        for(Shipments shpList : shpid) {
		        	if(formatter.formatCellValue(row.getCell(0)).equals(shpList.getInvoice_Number())) {		
		        				        				    		   
		        	}		        	
		        }
		       		      		
				String Shipment_Id = null;
				for (Shipments sh : shpid) {
					Shipment_Id = sh.getShipment_Id();
					System.out.println("result - " + sh.getShipment_Id());
				}
				System.out.println("shpmntID"+ Shipment_Id);
				
				Query query_tran = new Query(Criteria.where("Shipment_Id").is(Shipment_Id));
				Update update_tran = new Update();
				
				try {
					String device_id = formatter.formatCellValue(row.getCell(2));
					String numAtZero = Character.toString(device_id.charAt(0));
					System.out.println(numAtZero);
//					char charAtZero = device_id.charAt(0);
//					System.out.println(charAtZero);
					if(numAtZero == "0") {
						System.out.println("in if "+formatter.formatCellValue(row.getCell(2)));
						update_tran.set("Device_Id", formatter.formatCellValue(row.getCell(2)));
						
					}
					else if (numAtZero != "0" || numAtZero == "1"){
						System.out.println("in else if "+formatter.formatCellValue(row.getCell(2)));
						update_tran.set("Device_Id", "00" + formatter.formatCellValue(row.getCell(2)));	
					}
					else {
						System.out.println("in else "+formatter.formatCellValue(row.getCell(2)));
						update_tran.set("Device_Id", formatter.formatCellValue(row.getCell(2)));
					}
				}
				catch(Exception e){
					System.out.println("Exception in Device Id");
				}
				
				update_tran.set("Shipment_Num", formatter.formatCellValue(row.getCell(1)));
//				update_tran.set("Device_Id", "00" + formatter.formatCellValue(row.getCell(2)));	
				mongoTemplate.updateMulti(query_tran, update_tran, "ShipmentTransactions");
				mongoTemplate.updateMulti(query_tran, update_tran, "Shipments");
								
				List<ShipmentTransactions> list = shiptransrepo.findByShipment_Id(Shipment_Id);
				System.out.println(list);
				for (ShipmentTransactions transactions : list) {
					if (transactions.getEvent_Name().equals(formatter.formatCellValue(row.getCell(3)))
							&& transactions.getShipment_Id().equals(Shipment_Id)) {
						if (transactions.getEvent_Status().equals("Initialized")) {
							
							Query query_trans = new Query(); 
							query_trans.addCriteria(
									new Criteria().andOperator((Criteria.where("Shipment_Id").is(Shipment_Id)), 
											Criteria.where("Event_Status").is("Initialized")));
							
							Update update_trans = new Update();							
							update_trans.set("Event_Status", "Completed");
							update_trans.set("EventReferenceNumber", "");
							update_trans.set("TypeOfReference", "");
							update_trans.set("Event_Exec_Date", strDate);					    
							update_trans.set("EvidenceList", null);

						mongoTemplate.updateFirst(query_trans, update_trans, "ShipmentTransactions");
						System.out.println(update_trans);
						
						long eventslno = Long.valueOf((transactions.getEvent_SNo() + 1));
						System.out.println("Long valueeeee::::" + eventslno);
						ShipmentTransactions eventsno = shiptransrepo.findByEvent_Sno(eventslno);
						String reqval = eventsno.getEvent_Name();
						System.out.println("Reqval::::" + reqval);
						System.out.println("Eventss updating to initailization" + eventsno);
						System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
								+ eventsno.getEvent_SNo());
						Query query2 = new Query();
						Update update2 = new Update();

						query2.addCriteria(
								new Criteria().andOperator(Criteria.where("Shipment_Id").is(eventsno.getShipment_Id()),
										Criteria.where("Event_SNo").is(eventsno.getEvent_SNo())));

						System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
								+ eventsno.getEvent_SNo());

						update2.set("Event_Status", "Initialized");
						mongoTemplate.updateMulti(query2, update2, "ShipmentTransactions");

						Query query1 = new Query();
						Update update1 = new Update();
						query1.addCriteria(Criteria.where("Shipment_Id").is(Shipment_Id));
						update1.set("Shipment_Status", reqval);
						mongoTemplate.updateFirst(query1, update1, "Shipments");
					  }
					}																				
				}								
		}	
				else {
					 System.out.println("shpmntID is null so now in else   ");
					 errorexcel.setDelivery_number(formatter.formatCellValue(row.getCell(0)));
					 errorexcel.setInvoice_number(formatter.formatCellValue(row.getCell(1)));
					 errorexcel.setDevice_Id(formatter.formatCellValue(row.getCell(2)));
					 errorexcel.setEvent_name(formatter.formatCellValue(row.getCell(3)));
					 errorexcel.setEvent_status(formatter.formatCellValue(row.getCell(4)));											
					 mongoTemplate.insert(errorexcel, "ErrorExcel"); 
					 errorlist.add(errorexcel);
				}
				
				continue; 
		}									     				
				 if(row.getPhysicalNumberOfCells() == 4) {
	
				        System.out.println(formatter.formatCellValue(row.getCell(0)));
				        System.out.println("00"+formatter.formatCellValue(row.getCell(1)));
				        System.out.println(formatter.formatCellValue(row.getCell(2)));
				        System.out.println(formatter.formatCellValue(row.getCell(3)));
				        System.out.println("Empty cell    "+formatter.formatCellValue(row.getCell(4)));

		        		Query query_spid = new Query();
						query_spid.addCriteria(
								new Criteria().andOperator(Criteria.where("Invoice_Number").is(formatter.formatCellValue(row.getCell(0)))));
						List<Shipments> shpid = mongoTemplate.find(query_spid, Shipments.class);
						System.out.println("list shpid  ");
						System.out.println(shpid.isEmpty());
						System.out.println("getting shpid list  ");
						System.out.println(shpid);
						
						if(!shpid.isEmpty()) {
						
				        for(Shipments shpList : shpid) {
				        	if(formatter.formatCellValue(row.getCell(0)).equals(shpList.getInvoice_Number())) {		
				        				        				    		   
				        	}		        	
				        }
						
						String Shipment_Id = null;
						for (Shipments sh : shpid) {
							Shipment_Id = sh.getShipment_Id();
					    System.out.println("result - " + sh.getShipment_Id());
						}
						System.out.println("shpmntID"+ Shipment_Id);
						
						Query query_tran = new Query(Criteria.where("Shipment_Id").is(Shipment_Id));
						
						Update update_tran = new Update();
						try {
							String device_id = formatter.formatCellValue(row.getCell(1));
							String numAtZero = Character.toString(device_id.charAt(0));
							System.out.println("getting char at zero index");
							System.out.println(numAtZero);
							if(numAtZero == "0") {
								System.out.println("in if "+formatter.formatCellValue(row.getCell(1)));
								update_tran.set("Device_Id", formatter.formatCellValue(row.getCell(1)));
								
							}
							else if (numAtZero != "0" || numAtZero == "1"){
								System.out.println("in else if "+formatter.formatCellValue(row.getCell(1)));
								update_tran.set("Device_Id", "00" + formatter.formatCellValue(row.getCell(1)));	
							}
							else {
								System.out.println("in else "+formatter.formatCellValue(row.getCell(1)));
								update_tran.set("Device_Id", formatter.formatCellValue(row.getCell(1)));
							}
						}
						catch(Exception e){
							System.out.println("Exception in Device Id");
						}					
//						update_tran.set("Device_Id", "00" + formatter.formatCellValue(row.getCell(1)));
						mongoTemplate.updateMulti(query_tran, update_tran, "ShipmentTransactions");
						mongoTemplate.updateMulti(query_tran, update_tran, "Shipments");
										
						List<ShipmentTransactions> list = shiptransrepo.findByShipment_Id(Shipment_Id);
						System.out.println(list);
						for (ShipmentTransactions transactions : list) {
							if (transactions.getEvent_Name().equals(formatter.formatCellValue(row.getCell(2)))
									&& transactions.getShipment_Id().equals(Shipment_Id)) {
								if (transactions.getEvent_Status().equals("Initialized")) {
																	
									Query query_trans = new Query();
									query_trans.addCriteria(
											new Criteria().andOperator((Criteria.where("Shipment_Id").is(Shipment_Id)), 
													Criteria.where("Event_Status").is("Initialized")));
									Update update_trans = new Update();
									update_trans.set("Event_Status", formatter.formatCellValue(row.getCell(3)));
									update_trans.set("EventReferenceNumber", "");
									update_trans.set("TypeOfReference", "");
									update_trans.set("Event_Exec_Date", strDate);					    
									update_trans.set("EvidenceList", null);
//								}
														
								mongoTemplate.updateFirst(query_trans, update_trans, "ShipmentTransactions");
								System.out.println(update_trans);
								
								long eventslno = Long.valueOf((transactions.getEvent_SNo() + 1));
								System.out.println("Long valueeeee::::" + eventslno);
								ShipmentTransactions eventsno = shiptransrepo.findByEvent_Sno(eventslno);
								String reqval = eventsno.getEvent_Name();
								System.out.println("Reqval::::" + reqval);
								System.out.println("Eventss updating to initailization" + eventsno);
								System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
										+ eventsno.getEvent_SNo());
								Query query2 = new Query();
								Update update2 = new Update();

								query2.addCriteria(
										new Criteria().andOperator(Criteria.where("Shipment_Id").is(eventsno.getShipment_Id()),
												Criteria.where("Event_SNo").is(eventsno.getEvent_SNo())));

								System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
										+ eventsno.getEvent_SNo());

								update2.set("Event_Status", "Initialized");
								mongoTemplate.updateMulti(query2, update2, "ShipmentTransactions");

								Query query1 = new Query();
								Update update1 = new Update();
								query1.addCriteria(Criteria.where("Shipment_Id").is(Shipment_Id));
								update1.set("Shipment_Status", reqval);
								mongoTemplate.updateFirst(query1, update1, "Shipments");
							}
						  }																				
						}
					}
					else {
							 System.out.println("shpmntID is null so now in else  ");
							 errorexcel.setDelivery_number(formatter.formatCellValue(row.getCell(0)));
							 errorexcel.setDevice_Id(formatter.formatCellValue(row.getCell(1)));
							 errorexcel.setEvent_name(formatter.formatCellValue(row.getCell(2)));
							 errorexcel.setEvent_status(formatter.formatCellValue(row.getCell(3)));						
							 errorexcel.setInvoice_number("");
							 mongoTemplate.insert(errorexcel, "ErrorExcel"); 
							 errorlist.add(errorexcel);
						}						
						continue; 
				}	
				 
				 if(row.getPhysicalNumberOfCells() == 3) {

				        System.out.println(formatter.formatCellValue(row.getCell(0)));
				        System.out.println(formatter.formatCellValue(row.getCell(1)));
				        System.out.println(formatter.formatCellValue(row.getCell(2)));
				        System.out.println("Empty cell  "+formatter.formatCellValue(row.getCell(3)));
				        System.out.println("Empty cell  "+formatter.formatCellValue(row.getCell(4)));
				        
		        		Query query_spid = new Query();
						query_spid.addCriteria(
								new Criteria().andOperator(Criteria.where("Invoice_Number").is(formatter.formatCellValue(row.getCell(0)))));
						List<Shipments> shpid = mongoTemplate.find(query_spid, Shipments.class);
						System.out.println("list shpid  ");
						System.out.println(shpid.isEmpty());
						System.out.println("getting shpid list  ");
						System.out.println(shpid);
						 
					if(!shpid.isEmpty()) {						
						
				        for(Shipments shpList : shpid) {
				        	if(formatter.formatCellValue(row.getCell(0)).equals(shpList.getInvoice_Number())) {		
				        		  System.out.println("in if condition  "+formatter.formatCellValue(row.getCell(0)));
							      System.out.println("in if condition  "+formatter.formatCellValue(row.getCell(1)));
							      System.out.println("in if condition  "+formatter.formatCellValue(row.getCell(2)));
				        	
				        	}	
				        	
			        }
						String Shipment_Id = null;
						for (Shipments sh : shpid) {
							Shipment_Id = sh.getShipment_Id();
					    System.out.println("result - " + sh.getShipment_Id());
						}
						System.out.println("shpmntID  "+Shipment_Id);						
																												
						List<ShipmentTransactions> list = shiptransrepo.findByShipment_Id(Shipment_Id);
						System.out.println("list of Transactions");
						System.out.println(list);
						for (ShipmentTransactions transactions : list) {
							if (transactions.getEvent_Name().equals(formatter.formatCellValue(row.getCell(1)))
									&& transactions.getShipment_Id().equals(Shipment_Id)) {
								if (transactions.getEvent_Status().equals("Initialized")) {	
									
									Query query_tran = new Query();
									query_tran.addCriteria(
											new Criteria().andOperator((Criteria.where("Shipment_Id").is(Shipment_Id)), 
													Criteria.where("Event_Status").is("Initialized")));
									
									Update update_trans = new Update();
							        update_trans.set("Event_Status", "Completed");
									update_trans.set("EventReferenceNumber", "");
									update_trans.set("TypeOfReference", "");
									update_trans.set("Event_Exec_Date", strDate);					    
									update_trans.set("EvidenceList", null);
//								}
//							}
								System.out.println("update_trans::::");
								System.out.println(update_trans);
								mongoTemplate.updateFirst(query_tran, update_trans, "ShipmentTransactions");
												
								long eventslno = Long.valueOf((transactions.getEvent_SNo() + 1));
								System.out.println("Long valueeeee::::" + eventslno);
								ShipmentTransactions eventsno = shiptransrepo.findByEvent_Sno(eventslno);
								String reqval = eventsno.getEvent_Name();
								System.out.println("Reqval::::" + reqval);
								System.out.println("Eventss updating to initailization" + eventsno);
								System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
										+ eventsno.getEvent_SNo());
								Query query2 = new Query();
								Update update2 = new Update();

								query2.addCriteria(
										new Criteria().andOperator(Criteria.where("Shipment_Id").is(eventsno.getShipment_Id()),
												Criteria.where("Event_SNo").is(eventsno.getEvent_SNo())));

								System.out.println("query displaying for criteria" + eventsno.getShipment_Id() + "-------------"
										+ eventsno.getEvent_SNo());

								update2.set("Event_Status", "Initialized");
								mongoTemplate.updateMulti(query2, update2, "ShipmentTransactions");

								Query query1 = new Query();
								Update update1 = new Update();
								query1.addCriteria(Criteria.where("Shipment_Id").is(Shipment_Id));
								update1.set("Shipment_Status", reqval);
								mongoTemplate.updateFirst(query1, update1, "Shipments");	
								
								}
							}																				
						}						  								 	
		          }
						else {
							 System.out.println("shpmntID is null so now in else   ");
							 errorexcel.setDelivery_number(formatter.formatCellValue(row.getCell(0)));
							 errorexcel.setEvent_name(formatter.formatCellValue(row.getCell(1)));
							 errorexcel.setEvent_status(formatter.formatCellValue(row.getCell(2)));
							 errorexcel.setDevice_Id("");
							 errorexcel.setInvoice_number("");
							 mongoTemplate.insert(errorexcel, "ErrorExcel");
							 errorlist.add(errorexcel);
						}
						 continue;   
				 	
				 }	
		    }
		return errorlist;
	}
}
