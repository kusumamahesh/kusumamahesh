package com.SCMXPert.sbmongodb.document;

public class AlternateContacts {

	private String AltrContactName;
	private String AltrEmailAddress;
	private String AltrPhoneNumber;

	public AlternateContacts() {
		// TODO Auto-generated constructor stub
	}

	public String getAltrContactName() {
		return AltrContactName;
	}

	public void setAltrContactName(String altrContactName) {
		AltrContactName = altrContactName;
	}

	public String getAltrEmailAddress() {
		return AltrEmailAddress;
	}

	public void setAltrEmailAddress(String altrEmailAddress) {
		AltrEmailAddress = altrEmailAddress;
	}

	public String getAltrPhoneNumber() {
		return AltrPhoneNumber;
	}

	public void setAltrPhoneNumber(String altrPhoneNumber) {
		AltrPhoneNumber = altrPhoneNumber;
	}

}
