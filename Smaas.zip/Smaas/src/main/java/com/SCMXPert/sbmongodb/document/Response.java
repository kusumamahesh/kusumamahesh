package com.SCMXPert.sbmongodb.document;

import java.util.List;

public class Response {

	

	public String message;
	public boolean Status;
//	public boolean isStatus() {
//		return Status;
//	}

	public boolean setStatus(boolean status) {
		return Status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	

	

	





	
	
}
