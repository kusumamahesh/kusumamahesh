package com.SCMXPert.sbmongodb.document;

public class Cities {

}
