package com.sec.AuthServerSecurity.config;

public class Response {
	public String messasge;
	public boolean flag;

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public void setMessasge(String messasge) {
		this.messasge = messasge;
	}

	public String getMessasge() {
		return messasge;
	}

}
