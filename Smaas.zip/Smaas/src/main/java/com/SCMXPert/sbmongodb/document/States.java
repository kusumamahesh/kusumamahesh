package com.SCMXPert.sbmongodb.document;

import java.util.List;

public class States {

	private String[] Cities;
	private String StateName;
	public String[] getCities() {
		return Cities;
	}
	public void setCities(String[] cities) {
		Cities = cities;
	}
	public String getStateName() {
		return StateName;
	}
	public void setStateName(String stateName) {
		StateName = stateName;
	}
	
	
}
